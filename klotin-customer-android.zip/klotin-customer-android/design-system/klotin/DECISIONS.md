# Klotin design decisions

Where the app departs from what `search.py --design-system` generated (see `MASTER.md`,
`tokens.json`, `tokens.css`), and why. Everything not listed here follows the generated system.

Generated with: `search.py "logistics delivery courier mobile app customer account" --design-system --persist --tokens css --variance 3 --motion 3 --density 5 -p "Klotin"`

| Area | Generated | Used in the app | Reason |
|------|-----------|-----------------|--------|
| Body font | Playfair Display (serif) | Inter (system fallback) | The generator's mood tags for that pairing are "editorial, poster, luxury". The `typography` domain lists "Minimal Swiss" (Inter only) as the match for dashboards, enterprise and form-heavy apps. |
| Font delivery | Google Fonts import | System font (Roboto) | Inter is not bundled in the APK. The pairing's own notes give system fonts as the fallback on Android. Bundle `inter.ttf` under `res/font` to get Inter exactly. |
| Input border | `border` #BFDBFE | `outline` #64748B for fields, #BFDBFE for dividers | #BFDBFE is 1.4:1 on white. Form field boundaries need 3:1. |
| Error / destructive | #DC2626 | #B91C1C in light theme | #DC2626 is 4.44:1 on the generated background #EFF6FF. Inline error text needs 4.5:1. |
| Dark theme | not generated (light values only) | Derived, same hues | Checked with `tools/contrast_check.py`; every pair passes. |
| Shadows / hover lift | `translateY(-2px)` on hover | Ripple and colour change only | Hover does not exist on touch. The skill's rule for apps: pressed feedback must not shift layout. |
| Layout width | 1200px web container | Full-width phone layout, 16dp gutters | Mobile app. |
| Icons | Phosphor (web package) | Material Symbols, outlined, one family | Phosphor ships as a React/web package. Material icons come with Compose. One style per level, per pro-rules. |

## Rules taken from the skill's UX search and applied

| Rule (skill source) | Where it shows up |
|---|---|
| Accessible authentication: allow paste and password managers, no OTP-only dead end (`ux`, Critical) | OTP field accepts paste of the full code; password fields use `KeyboardType.Password`; email/phone sign-in alternative on every auth screen. |
| Visible label on every input, never placeholder-only (`web`, Critical; `ux`, High) | `KlotinTextField` always renders a label above the field. |
| Inline error under the field, plus a focusable error summary after a failed submit (`ux`, High) | `FormErrorSummary` at the top of each form; focus moves to it after a failed submit. |
| Validate on blur, not only on submit (`ux`) | Fields validate when they lose focus. |
| Show/hide password toggle (`ux`) | Password fields. |
| Loading, then success or error, after submit (`ux`) | Buttons show progress and disable while a request runs; a snackbar confirms success. |
| Confirm before delete (`ux`, High) | Address delete asks first. |
| Predictable back (`ux`, High) | `BackHandler` pops one screen; sign-in and home are roots. |
| 8dp between touch targets, 48dp minimum (`web`, pro-rules) | `Space.sm` gaps, `MinTouchTarget` on every control. |
| Stable `key` in lazy lists (`jetpack-compose`, High) | Address list uses `key = { it.id }`. |
| Expose immutable `StateFlow`; one source of truth (`jetpack-compose`, High) | `AppViewModel` exposes `StateFlow<AppState>`. |
| Event-based navigation, typed routes (`jetpack-compose`) | `sealed interface Route`; one-off messages go through a `Channel`. |
| Theme tokens, never hard-coded colours or sizes (`jetpack-compose`, High) | `KlotinTheme`, `Space`, `IconSize`; screens use `MaterialTheme.colorScheme` only. |

## No database match

The skill returned 0 results for "keyboard" and "touch target" under `--stack jetpack-compose`
(retried once, as the skill instructs). For those two topics the app follows the `web`
(app-interface) domain results and `references/pro-rules.md` instead.
