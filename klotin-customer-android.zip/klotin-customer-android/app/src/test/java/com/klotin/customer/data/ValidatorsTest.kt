package com.klotin.customer.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidatorsTest {

    @Test
    fun phoneAcceptsEveryCommonNigerianFormat() {
        val expected = "+2348031234567"
        listOf(
            "08031234567",
            "0803 123 4567",
            "803 123 4567",
            "8031234567",
            "2348031234567",
            "+2348031234567",
            "+234 803 123 4567",
            "+234 0803 123 4567",
            "(0803) 123-4567",
        ).forEach { assertEquals("input: $it", expected, Validators.normalizePhone(it)) }
    }

    @Test
    fun phoneRejectsNumbersThatAreNotNigerianMobiles() {
        listOf("", "123", "0803123456", "080312345678", "05031234567", "+14155552671", "abcdefghij")
            .forEach { assertNull("input: $it", Validators.normalizePhone(it)) }
    }

    @Test
    fun phoneFormattingAndMasking() {
        assertEquals("+234 803 123 4567", Validators.formatPhone("+2348031234567"))
        assertEquals("+234 803 ••• 4567", Validators.maskPhone("+2348031234567"))
        assertEquals("a••@example.com", Validators.maskEmail("ada@example.com"))
    }

    @Test
    fun emailChecks() {
        assertTrue(Validators.isEmail("ada@example.com"))
        assertTrue(Validators.isEmail("  Ada.Obi+test@mail.co.ng "))
        assertFalse(Validators.isEmail("ada@example"))
        assertFalse(Validators.isEmail("ada example@x.com"))
        assertFalse(Validators.isEmail(""))
        assertEquals("ada@example.com", Validators.normalizeEmail("  ADA@Example.com "))
    }

    @Test
    fun passwordRules() {
        assertEquals(3, Validators.passwordProblems("").size)
        assertEquals(listOf("At least one number"), Validators.passwordProblems("abcdefgh"))
        assertEquals(listOf("At least one letter"), Validators.passwordProblems("12345678"))
        assertTrue(Validators.passwordProblems("lagos2026go").isEmpty())
        assertNull(Validators.validatePassword("lagos2026go"))
        assertNotNull(Validators.validatePassword("short1"))
    }

    @Test
    fun registrationReportsEveryBadField() {
        val errors = Validators.validateRegistration("", "nope", "123", "x")
        assertEquals(setOf("fullName", "email", "phone", "password"), errors.keys)
        assertTrue(Validators.validateRegistration("Ada Obi", "ada@example.com", "0803 123 4567", "lagos2026go").isEmpty())
    }

    private fun draft(
        label: AddressLabel = AddressLabel.HOME,
        custom: String = "",
        street: String = "12 Adeola Odeku St",
        city: String = "Victoria Island",
        state: String = "Lagos",
        phone: String = "",
    ) = AddressDraft(null, label, custom, phone, street, "", city, state, false)

    @Test
    fun addressValidation() {
        assertTrue(Validators.validateAddress(draft()).isEmpty())
        assertEquals(setOf("street", "city", "state"), Validators.validateAddress(draft(street = "", city = " ", state = "")).keys)
        assertEquals(setOf("state"), Validators.validateAddress(draft(state = "Atlantis")).keys)
        assertEquals(setOf("customLabel"), Validators.validateAddress(draft(label = AddressLabel.OTHER)).keys)
        assertTrue(Validators.validateAddress(draft(label = AddressLabel.OTHER, custom = "Mum's place")).isEmpty())
        assertEquals(setOf("contactPhone"), Validators.validateAddress(draft(phone = "12345")).keys)
    }

    @Test
    fun allThirtySevenStatesAreListed() {
        assertEquals(37, Validators.NIGERIAN_STATES.size)
        assertEquals(37, Validators.NIGERIAN_STATES.toSet().size)
        assertTrue("Lagos" in Validators.NIGERIAN_STATES)
        assertTrue("FCT Abuja" in Validators.NIGERIAN_STATES)
    }

    @Test
    fun identityNumbers() {
        assertNull(Validators.validateIdNumber(IdType.NIN, "123 4567 8901"))
        assertNotNull(Validators.validateIdNumber(IdType.NIN, "1234567890"))
        assertNull(Validators.validateIdNumber(IdType.PASSPORT, "A12345678"))
        assertNotNull(Validators.validateIdNumber(IdType.PASSPORT, "12345678A"))
        assertNull(Validators.validateIdNumber(IdType.DRIVERS_LICENCE, "ABC123456789"))
        assertNotNull(Validators.validateIdNumber(IdType.DRIVERS_LICENCE, "ABC-123"))
        assertNull(Validators.validateIdNumber(IdType.VOTERS_CARD, "90F5B0C1D2E3F4A5B6C"))
        assertNotNull(Validators.validateIdNumber(IdType.VOTERS_CARD, ""))
    }

    @Test
    fun verificationProgressCountsThreeSteps() {
        val base = User(
            id = "u", fullName = "Ada Obi", email = "ada@example.com", phone = "+2348031234567",
            emailVerified = false, phoneVerified = false, provider = AuthProvider.PASSWORD,
            addresses = emptyList(), identity = IdentityVerification(), createdAt = 0,
        )
        assertEquals(0, base.verificationProgress().completed)
        val partly = base.copy(emailVerified = true, identity = IdentityVerification(status = IdStatus.PENDING))
        assertEquals(1, partly.verificationProgress().completed)
        val full = base.copy(emailVerified = true, phoneVerified = true, identity = IdentityVerification(status = IdStatus.APPROVED))
        assertTrue(full.verificationProgress().isComplete)
        assertEquals(3, full.verificationProgress().total)
    }

    @Test
    fun userHelpers() {
        val u = User(
            id = "u", fullName = "  ada  obi ", email = null, phone = null,
            emailVerified = false, phoneVerified = false, provider = AuthProvider.PASSWORD,
            addresses = emptyList(), identity = IdentityVerification(), createdAt = 0,
        )
        assertEquals("ada", u.firstName)
        assertEquals("AO", u.initials)
    }
}
