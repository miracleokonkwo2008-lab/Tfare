package com.klotin.customer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.klotin.customer.app.AppController
import com.klotin.customer.app.Outcome
import com.klotin.customer.app.Route
import com.klotin.customer.data.AuthProvider
import com.klotin.customer.data.User
import com.klotin.customer.data.Validators
import com.klotin.customer.data.verificationProgress
import com.klotin.customer.ui.components.Avatar
import com.klotin.customer.ui.components.FormErrorSummary
import com.klotin.customer.ui.components.FormState
import com.klotin.customer.ui.components.KlotinCard
import com.klotin.customer.ui.components.KlotinTextField
import com.klotin.customer.ui.components.KlotinTopBar
import com.klotin.customer.ui.components.LinkButton
import com.klotin.customer.ui.components.ListRow
import com.klotin.customer.ui.components.PrimaryButton
import com.klotin.customer.ui.components.RowDivider
import com.klotin.customer.ui.components.ScreenColumn
import com.klotin.customer.ui.components.SecondaryButton
import com.klotin.customer.ui.components.SectionTitle
import com.klotin.customer.ui.components.StatusPill
import com.klotin.customer.ui.components.Tone
import com.klotin.customer.ui.theme.IconSize
import com.klotin.customer.ui.theme.Space
import com.klotin.customer.ui.theme.klotinExtras
import kotlinx.coroutines.launch

// ---- Home ------------------------------------------------------------------------------

@Composable
fun HomeScreen(user: User, controller: AppController) {
    val progress = user.verificationProgress()
    val address = user.defaultAddress

    Column {
        KlotinTopBar(title = "Klotin", onBack = null)
        ScreenColumn {
            Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                Text(
                    "Hi, ${user.firstName}",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    if (progress.isComplete) "Your account is fully set up." else "Finish setting up your account.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            KlotinCard {
                Column(Modifier.padding(Space.md), verticalArrangement = Arrangement.spacedBy(Space.md)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle("Verification", Modifier.weight(1f))
                        if (progress.isComplete) {
                            StatusPill("Fully verified", Tone.GOOD, Icons.Outlined.Verified)
                        } else {
                            Text(
                                "${progress.completed} of ${progress.total} done",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    LinearProgressIndicator(
                        progress = { progress.completed.toFloat() / progress.total },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                        progress.done.forEach { (step, done) ->
                            StepLine(step.title, done)
                        }
                    }
                    if (!progress.isComplete) {
                        PrimaryButton("Continue verification", onClick = { controller.navigate(Route.Verification) })
                    }
                }
            }

            KlotinCard {
                Column(Modifier.padding(Space.md), verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    SectionTitle("Default address")
                    if (address != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                            Icon(
                                Icons.Outlined.LocationOn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(IconSize.md),
                            )
                            Text(address.displayLabel, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Text(address.summary, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                        LinkButton("Manage addresses", onClick = { controller.selectTab(Route.Addresses) })
                    } else {
                        Text(
                            "Save an address so riders know where to find you.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        SecondaryButton(
                            "Add an address",
                            onClick = { controller.navigate(Route.AddressForm(null)) },
                            icon = Icons.Outlined.LocationOn,
                        )
                    }
                }
            }
            Spacer(Modifier.height(Space.md))
        }
    }
}

/** One read-only line in a checklist. The icon and the word both say whether it is done. */
@Composable
private fun StepLine(title: String, done: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
        Icon(
            imageVector = if (done) Icons.Outlined.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
            contentDescription = null,
            tint = if (done) klotinExtras.success else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(IconSize.md),
        )
        Text(
            "$title, ${if (done) "done" else "to do"}",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

// ---- Account ---------------------------------------------------------------------------

@Composable
fun AccountScreen(user: User, busy: Boolean, controller: AppController) {
    val scope = rememberCoroutineScope()
    val progress = user.verificationProgress()

    Column {
        KlotinTopBar(title = "Account", onBack = null)
        ScreenColumn {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.md)) {
                Avatar(user.initials)
                Column(Modifier.weight(1f)) {
                    Text(user.fullName, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                    user.email?.let {
                        Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    user.phone?.let {
                        Text(Validators.formatPhone(it), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (user.provider != AuthProvider.PASSWORD) {
                        Text(
                            "Signed in with ${user.provider.name.lowercase().replaceFirstChar { c -> c.uppercase() }}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            KlotinCard {
                ListRow(
                    icon = Icons.Outlined.Edit,
                    title = "Edit profile",
                    subtitle = "Name, email and phone number",
                    onClick = { controller.navigate(Route.EditProfile) },
                )
                RowDivider()
                ListRow(
                    icon = Icons.Outlined.Verified,
                    title = "Verification",
                    subtitle = "${progress.completed} of ${progress.total} steps done",
                    onClick = { controller.navigate(Route.Verification) },
                )
                RowDivider()
                ListRow(
                    icon = Icons.Outlined.LocationOn,
                    title = "Saved addresses",
                    subtitle = if (user.addresses.isEmpty()) "None yet" else "${user.addresses.size} saved",
                    onClick = { controller.selectTab(Route.Addresses) },
                )
            }

            SecondaryButton(
                "Sign out",
                onClick = { scope.launch { controller.signOut() } },
                enabled = !busy,
                icon = Icons.AutoMirrored.Outlined.Logout,
            )
            Text(
                "Klotin 0.1.0 · demo build",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
            Spacer(Modifier.height(Space.md))
        }
    }
}

// ---- Edit profile ----------------------------------------------------------------------

@Composable
fun EditProfileScreen(user: User, busy: Boolean, controller: AppController) {
    val scope = rememberCoroutineScope()
    var fullName by rememberSaveable(user.id) { mutableStateOf(user.fullName) }
    var email by rememberSaveable(user.id) { mutableStateOf(user.email.orEmpty()) }
    var phone by rememberSaveable(user.id) { mutableStateOf(user.phone?.let { Validators.formatPhone(it) }.orEmpty()) }
    val form = remember { FormState(listOf("fullName", "email", "phone")) }
    // Social accounts have no phone until the customer adds one, so it may stay empty for them.
    val phoneOptional = user.provider != AuthProvider.PASSWORD

    fun submit() {
        val found = buildMap {
            Validators.validateName(fullName)?.let { put("fullName", it) }
            Validators.validateEmail(email)?.let { put("email", it) }
            if (!(phoneOptional && phone.isBlank())) {
                Validators.validatePhone(phone)?.let { put("phone", it) }
            }
        }
        if (found.isNotEmpty()) {
            form.failSubmit(found)
            return
        }
        form.reset()
        scope.launch {
            val result = controller.saveProfile(fullName, email, phone)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    Column {
        KlotinTopBar(title = "Edit profile", onBack = { controller.back() })
        ScreenColumn {
            FormErrorSummary(form)

            Column {
                KlotinTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        form.clear("fullName")
                    },
                    label = "Full name",
                    capitalization = KeyboardCapitalization.Words,
                    leadingIcon = Icons.Outlined.Person,
                    errorText = form.errors["fullName"],
                    focusRequester = form.focus["fullName"],
                    onBlur = { form.setError("fullName", Validators.validateName(fullName)) },
                )
                KlotinTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        form.clear("email")
                    },
                    label = "Email address",
                    helperText = if (user.emailVerified) "Verified. Changing it means verifying again." else "Not verified yet.",
                    keyboardType = KeyboardType.Email,
                    leadingIcon = Icons.Outlined.Email,
                    errorText = form.errors["email"],
                    focusRequester = form.focus["email"],
                    onBlur = { form.setError("email", Validators.validateEmail(email)) },
                )
                KlotinTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        form.clear("phone")
                    },
                    label = if (phoneOptional) "Phone number (optional)" else "Phone number",
                    helperText = when {
                        user.phone == null -> "Add a number to verify it."
                        user.phoneVerified -> "Verified. Changing it means verifying again."
                        else -> "Not verified yet."
                    },
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                    onImeAction = { submit() },
                    leadingIcon = Icons.Outlined.Phone,
                    errorText = form.errors["phone"],
                    focusRequester = form.focus["phone"],
                    onBlur = {
                        if (!(phoneOptional && phone.isBlank())) form.setError("phone", Validators.validatePhone(phone))
                    },
                )
            }

            PrimaryButton("Save changes", onClick = { submit() }, loading = busy)
            Spacer(Modifier.height(Space.md))
        }
    }
}
