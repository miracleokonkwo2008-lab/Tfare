package com.klotin.customer.app

import com.klotin.customer.data.AddressDraft
import com.klotin.customer.data.AddressLabel
import com.klotin.customer.data.AuthProvider
import com.klotin.customer.data.Channel
import com.klotin.customer.data.ErrorCode
import com.klotin.customer.data.IdStatus
import com.klotin.customer.data.IdType
import com.klotin.customer.data.InMemoryStore
import com.klotin.customer.data.MockBackend
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppControllerTest {

    private val store = InMemoryStore()

    private fun controller(s: InMemoryStore = store): AppController {
        val backend = MockBackend(s, randomCode = { 123456 })
        return AppController(backend, CoroutineScope(SupervisorJob() + Dispatchers.Default))
    }

    private suspend fun AppController.ready(): AppState =
        withTimeout(5_000) { state.first { it.phase != Phase.LOADING } }

    private suspend fun AppController.signUpAda() =
        signUp("Ada Obi", "ada@example.com", "0803 123 4567", "lagos2026go")

    @Test
    fun startsSignedOutOnTheSignInScreen() = runBlocking {
        val c = controller()
        val s = c.ready()
        assertEquals(Phase.SIGNED_OUT, s.phase)
        assertEquals(listOf<Route>(Route.SignIn), s.stack)
        assertNull(s.user)
    }

    @Test
    fun signUpLandsOnHomeWithThePhoneCodeScreenOnTop() = runBlocking {
        val c = controller()
        c.ready()
        assertEquals(Outcome.Ok, c.signUpAda())

        val s = c.state.value
        assertEquals(Phase.SIGNED_IN, s.phase)
        assertEquals(listOf(Route.Home, Route.Otp(Channel.PHONE)), s.stack)
        assertEquals("123456", s.otp!!.demoCode)
        assertFalse(s.busy)
    }

    @Test
    fun backSkipsTheCodeScreenAndLeavesTheAppAtTheRoot() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda()

        assertTrue(c.back())
        assertEquals(listOf<Route>(Route.Home), c.state.value.stack)
        assertNull(c.state.value.otp)
        assertFalse(c.back()) // at a root: caller leaves the app
        assertEquals(listOf<Route>(Route.Home), c.state.value.stack)
        assertFalse(c.state.value.user!!.phoneVerified)
    }

    @Test
    fun correctCodeVerifiesAndReturnsToTheScreenBelow() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda()

        val bad = c.submitOtp("000000") as Outcome.Failed
        assertEquals(ErrorCode.WRONG_CODE, bad.code)
        assertEquals("code", bad.field)
        assertEquals(Route.Otp(Channel.PHONE), c.state.value.current) // still on the code screen

        assertEquals(Outcome.Ok, c.submitOtp(" 123456 "))
        val s = c.state.value
        assertEquals(listOf<Route>(Route.Home), s.stack)
        assertTrue(s.user!!.phoneVerified)
        assertNull(s.otp)
        assertEquals(UiEvent.Message("Phone number verified."), c.events.first())
    }

    @Test
    fun validationErrorsComeBackWithTheirFieldAndChangeNothing() = runBlocking {
        val c = controller()
        c.ready()
        val r = c.signUp("Ada Obi", "not-an-email", "0803 123 4567", "lagos2026go") as Outcome.Failed
        assertEquals("email", r.field)
        assertEquals(ErrorCode.VALIDATION, r.code)
        assertEquals(Phase.SIGNED_OUT, c.state.value.phase)
        assertFalse(c.state.value.busy)
    }

    @Test
    fun signInFailureIsGenericAndSignInSucceedsWithEmailOrPhone() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.signOut()
        assertEquals(listOf<Route>(Route.SignIn), c.state.value.stack)

        val bad = c.signIn("ada@example.com", "wrong1234") as Outcome.Failed
        assertEquals(ErrorCode.INVALID_CREDENTIALS, bad.code)
        assertNull(bad.field)

        assertEquals(Outcome.Ok, c.signIn("08031234567", "lagos2026go"))
        assertEquals(listOf<Route>(Route.Home), c.state.value.stack)
    }

    @Test
    fun tabsReplaceTheStackAndPushedScreensStackOnTop() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.back()

        c.selectTab(Route.Account)
        assertEquals(listOf<Route>(Route.Account), c.state.value.stack)
        c.navigate(Route.EditProfile)
        c.navigate(Route.Verification)
        assertEquals(listOf(Route.Account, Route.EditProfile, Route.Verification), c.state.value.stack)
        assertTrue(c.state.value.canGoBack)
        c.back()
        assertEquals(Route.EditProfile, c.state.value.current)
    }

    @Test(expected = IllegalArgumentException::class)
    fun onlyTabRoutesCanBeSelectedAsTabs() {
        runBlocking {
            val c = controller()
            c.ready()
            c.selectTab(Route.Identity)
        }
    }

    @Test
    fun startOtpPushesTheCodeScreenFromVerification() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.back()
        c.navigate(Route.Verification)

        assertEquals(Outcome.Ok, c.startOtp(Channel.EMAIL))
        assertEquals(Route.Otp(Channel.EMAIL), c.state.value.current)
        assertEquals(Outcome.Ok, c.submitOtp("123456"))
        assertEquals(Route.Verification, c.state.value.current)
        assertTrue(c.state.value.user!!.emailVerified)
    }

    @Test
    fun profileSaveWarnsWhenContactDetailsChangeAndPopsTheForm() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.back()
        c.selectTab(Route.Account); c.navigate(Route.EditProfile)

        assertEquals(Outcome.Ok, c.saveProfile("Ada N. Obi", "ada.new@example.com", "08031234567"))
        assertEquals(listOf<Route>(Route.Account), c.state.value.stack)
        assertEquals("Ada N. Obi", c.state.value.user!!.fullName)
        assertEquals(UiEvent.Message("Profile saved. Verify your new contact details."), c.events.first())
    }

    @Test
    fun addressFlowSaveSetDefaultDelete() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.back()
        c.selectTab(Route.Addresses)

        fun draft(label: AddressLabel, street: String) =
            AddressDraft(null, label, "", "", street, "", "Ikeja", "Lagos", false)

        c.navigate(Route.AddressForm(null))
        assertEquals(Outcome.Ok, c.saveAddress(draft(AddressLabel.HOME, "1 Allen Ave")))
        assertEquals(listOf<Route>(Route.Addresses), c.state.value.stack)

        c.navigate(Route.AddressForm(null))
        assertEquals(Outcome.Ok, c.saveAddress(draft(AddressLabel.WORK, "2 Marina Rd")))
        val two = c.state.value.user!!.addresses
        assertEquals(listOf(true, false), two.map { it.isDefault })

        assertEquals(Outcome.Ok, c.setDefaultAddress(two[1].id))
        assertEquals(listOf(false, true), c.state.value.user!!.addresses.map { it.isDefault })

        assertEquals(Outcome.Ok, c.deleteAddress(two[1].id))
        val left = c.state.value.user!!.addresses
        assertEquals(1, left.size)
        assertTrue(left.single().isDefault)
    }

    @Test
    fun identityFlow() = runBlocking {
        val c = controller()
        c.ready(); c.signUpAda(); c.back()
        c.navigate(Route.Verification); c.navigate(Route.Identity)

        val bad = c.submitIdentity(IdType.NIN, "123") as Outcome.Failed
        assertEquals("number", bad.field)
        assertEquals(Route.Identity, c.state.value.current)

        assertEquals(Outcome.Ok, c.submitIdentity(IdType.NIN, "12345678901"))
        assertEquals(Route.Verification, c.state.value.current)
        assertEquals(IdStatus.PENDING, c.state.value.user!!.identity.status)

        assertEquals(Outcome.Ok, c.demoDecideIdentity(approve = true))
        assertEquals(IdStatus.APPROVED, c.state.value.user!!.identity.status)
    }

    @Test
    fun socialSignInSkipsTheCodeScreenAndHasAVerifiedEmail() = runBlocking {
        val c = controller()
        c.ready()
        assertEquals(Outcome.Ok, c.socialSignIn(AuthProvider.GOOGLE))
        val s = c.state.value
        assertEquals(listOf<Route>(Route.Home), s.stack)
        assertTrue(s.user!!.emailVerified)
        assertNull(s.user!!.phone)
    }

    @Test
    fun sessionSurvivesARestartOfTheController() = runBlocking {
        val first = controller()
        first.ready(); first.signUpAda()

        val second = controller()
        val s = second.ready()
        assertEquals(Phase.SIGNED_IN, s.phase)
        assertEquals("Ada Obi", s.user!!.fullName)
        assertEquals(listOf<Route>(Route.Home), s.stack)
        assertNotNull(s.user)
    }
}
