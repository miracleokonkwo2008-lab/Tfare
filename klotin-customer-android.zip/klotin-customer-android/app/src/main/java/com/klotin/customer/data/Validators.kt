package com.klotin.customer.data

/** Pure input rules. Nothing here touches Android, so it is cheap to unit test. */
object Validators {

    val NIGERIAN_STATES: List<String> = listOf(
        "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno",
        "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT Abuja", "Gombe", "Imo",
        "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos", "Nasarawa",
        "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", "Sokoto", "Taraba", "Yobe",
        "Zamfara",
    )

    const val MAX_ADDRESSES = 10
    const val MIN_PASSWORD_LENGTH = 8

    private val emailRegex = Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]{2,}$")
    private val ngMobileRegex = Regex("^[789][01]\\d{8}$")
    private val separators = Regex("[\\s\\-().]")

    fun normalizeEmail(input: String): String = input.trim().lowercase()

    fun isEmail(input: String): Boolean = emailRegex.matches(normalizeEmail(input))

    /**
     * Accepts 0803 123 4567, 803 123 4567, 2348031234567 or +234 803 123 4567
     * and returns +2348031234567. Returns null when it is not a Nigerian mobile number.
     */
    fun normalizePhone(input: String): String? {
        var s = input.replace(separators, "")
        s = when {
            s.startsWith("+234") -> s.drop(4)
            s.startsWith("234") && s.length >= 13 -> s.drop(3)
            else -> s
        }
        if (s.startsWith("0")) s = s.drop(1)
        return if (ngMobileRegex.matches(s)) "+234$s" else null
    }

    /** +2348031234567 -> +234 803 123 4567 */
    fun formatPhone(e164: String): String {
        val d = e164.removePrefix("+234")
        if (d.length != 10) return e164
        return "+234 ${d.substring(0, 3)} ${d.substring(3, 6)} ${d.substring(6)}"
    }

    /** +2348031234567 -> +234 803 ••• 4567 */
    fun maskPhone(e164: String): String {
        val d = e164.removePrefix("+234")
        if (d.length != 10) return e164
        return "+234 ${d.substring(0, 3)} ••• ${d.substring(6)}"
    }

    /** ada@example.com -> a••@example.com */
    fun maskEmail(email: String): String {
        val at = email.indexOf('@')
        if (at <= 0) return email
        return "${email.first()}••${email.substring(at)}"
    }

    fun passwordProblems(password: String): List<String> = buildList {
        if (password.length < MIN_PASSWORD_LENGTH) add("At least $MIN_PASSWORD_LENGTH characters")
        if (password.none { it.isLetter() }) add("At least one letter")
        if (password.none { it.isDigit() }) add("At least one number")
    }

    fun validateName(name: String): String? {
        val trimmed = name.trim()
        return when {
            trimmed.isEmpty() -> "Enter your full name."
            trimmed.length < 2 -> "Your name is too short."
            else -> null
        }
    }

    fun validateEmail(email: String): String? = when {
        email.isBlank() -> "Enter your email address."
        !isEmail(email) -> "Enter a valid email, like ada@example.com."
        else -> null
    }

    fun validatePhone(phone: String): String? = when {
        phone.isBlank() -> "Enter your phone number."
        normalizePhone(phone) == null -> "Enter a valid Nigerian mobile number, like 0803 123 4567."
        else -> null
    }

    fun validatePassword(password: String): String? = when {
        password.isEmpty() -> "Create a password."
        passwordProblems(password).isNotEmpty() ->
            "Use at least $MIN_PASSWORD_LENGTH characters with a letter and a number."
        else -> null
    }

    /** Returns field name -> message for every field that fails. Empty map means valid. */
    fun validateRegistration(
        fullName: String,
        email: String,
        phone: String,
        password: String,
    ): Map<String, String> = buildMap {
        validateName(fullName)?.let { put("fullName", it) }
        validateEmail(email)?.let { put("email", it) }
        validatePhone(phone)?.let { put("phone", it) }
        validatePassword(password)?.let { put("password", it) }
    }

    fun validateAddress(draft: AddressDraft): Map<String, String> = buildMap {
        if (draft.label == AddressLabel.OTHER && draft.customLabel.isBlank()) {
            put("customLabel", "Name this address, like Mum's place.")
        }
        if (draft.street.isBlank()) put("street", "Enter the street address.")
        if (draft.city.isBlank()) put("city", "Enter the city or area.")
        if (draft.state.isBlank()) {
            put("state", "Choose a state.")
        } else if (draft.state !in NIGERIAN_STATES) {
            put("state", "Choose a state from the list.")
        }
        if (draft.contactPhone.isNotBlank() && normalizePhone(draft.contactPhone) == null) {
            put("contactPhone", "Enter a valid Nigerian mobile number, or leave this empty.")
        }
    }

    fun validateIdNumber(type: IdType, number: String): String? {
        val n = number.trim().replace(" ", "")
        if (n.isEmpty()) return "Enter your ${type.title} number."
        val ok = when (type) {
            IdType.NIN -> Regex("^\\d{11}$").matches(n)
            IdType.DRIVERS_LICENCE -> Regex("^[A-Za-z0-9]{9,15}$").matches(n)
            IdType.VOTERS_CARD -> Regex("^[A-Za-z0-9]{9,19}$").matches(n)
            IdType.PASSPORT -> Regex("^[A-Za-z]\\d{8}$").matches(n)
        }
        return if (ok) null else "That does not look like a valid ${type.title} number (${type.hint})."
    }
}

enum class VerificationStep(val title: String) {
    EMAIL("Email address"),
    PHONE("Phone number"),
    IDENTITY("Identity document"),
}

data class VerificationProgress(val done: Map<VerificationStep, Boolean>) {
    val completed: Int get() = done.values.count { it }
    val total: Int get() = done.size
    val isComplete: Boolean get() = completed == total
}

fun User.verificationProgress(): VerificationProgress = VerificationProgress(
    linkedMapOf(
        VerificationStep.EMAIL to emailVerified,
        VerificationStep.PHONE to phoneVerified,
        VerificationStep.IDENTITY to (identity.status == IdStatus.APPROVED),
    ),
)
