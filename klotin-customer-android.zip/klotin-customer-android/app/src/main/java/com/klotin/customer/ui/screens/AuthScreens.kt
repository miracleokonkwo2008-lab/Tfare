package com.klotin.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.klotin.customer.app.AppController
import com.klotin.customer.app.Outcome
import com.klotin.customer.app.Route
import com.klotin.customer.data.AuthProvider
import com.klotin.customer.data.Validators
import com.klotin.customer.ui.components.DemoNote
import com.klotin.customer.ui.components.FormErrorSummary
import com.klotin.customer.ui.components.FormState
import com.klotin.customer.ui.components.KlotinTextField
import com.klotin.customer.ui.components.LinkButton
import com.klotin.customer.ui.components.OrDivider
import com.klotin.customer.ui.components.PasswordField
import com.klotin.customer.ui.components.PrimaryButton
import com.klotin.customer.ui.components.ScreenColumn
import com.klotin.customer.ui.components.SecondaryButton
import com.klotin.customer.ui.theme.IconSize
import com.klotin.customer.ui.theme.Space
import com.klotin.customer.ui.theme.klotinExtras
import kotlinx.coroutines.launch

@Composable
fun BrandMark(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Space.sm + Space.xs),
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .background(MaterialTheme.colorScheme.primary, MaterialTheme.shapes.small),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Outlined.LocalShipping,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(IconSize.md),
            )
        }
        Text(
            "Klotin",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
        )
    }
}

@Composable
fun SignInScreen(controller: AppController, busy: Boolean) {
    val scope = rememberCoroutineScope()
    var identifier by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    val form = remember { FormState(listOf("identifier", "password")) }

    fun submit() {
        val found = buildMap {
            if (identifier.isBlank()) put("identifier", "Enter your email or phone number.")
            if (password.isEmpty()) put("password", "Enter your password.")
        }
        if (found.isNotEmpty()) {
            form.failSubmit(found)
            return
        }
        form.reset()
        scope.launch {
            val result = controller.signIn(identifier, password)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    fun social(provider: AuthProvider) {
        form.reset()
        scope.launch {
            val result = controller.socialSignIn(provider)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    ScreenColumn {
        Spacer(Modifier.height(Space.md))
        BrandMark()
        Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
            Text(
                "Welcome back",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.semantics { heading() },
            )
            Text(
                "Sign in to request pickups and deliveries.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        FormErrorSummary(form)

        Column {
            KlotinTextField(
                value = identifier,
                onValueChange = {
                    identifier = it
                    form.clear("identifier")
                },
                label = "Email or phone number",
                keyboardType = KeyboardType.Email,
                leadingIcon = Icons.Outlined.Person,
                errorText = form.errors["identifier"],
                focusRequester = form.focus["identifier"],
            )
            PasswordField(
                value = password,
                onValueChange = {
                    password = it
                    form.clear("password")
                },
                errorText = form.errors["password"],
                focusRequester = form.focus["password"],
                onImeAction = { submit() },
            )
        }

        PrimaryButton("Sign in", onClick = { submit() }, loading = busy)

        OrDivider()

        // Brand logos: add the official Google and Facebook sign-in assets here before release.
        // The skill's rule is to use official brand assets as supplied, so none are drawn by hand.
        SecondaryButton(
            "Continue with Google",
            onClick = { social(AuthProvider.GOOGLE) },
            enabled = !busy,
            icon = Icons.Outlined.AccountCircle,
        )
        SecondaryButton(
            "Continue with Facebook",
            onClick = { social(AuthProvider.FACEBOOK) },
            enabled = !busy,
            icon = Icons.Outlined.AccountCircle,
        )

        Row(
            modifier = Modifier.align(Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "New to Klotin?",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LinkButton("Create an account", onClick = { controller.navigate(Route.SignUp) })
        }

        DemoNote("Nothing is sent from this build. Codes appear on screen, and Google and Facebook sign-in use a sample profile.")
        Spacer(Modifier.height(Space.md))
    }
}

@Composable
fun SignUpScreen(controller: AppController, busy: Boolean) {
    val scope = rememberCoroutineScope()
    var fullName by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    val form = remember { FormState(listOf("fullName", "email", "phone", "password")) }

    fun submit() {
        val found = Validators.validateRegistration(fullName, email, phone, password)
        if (found.isNotEmpty()) {
            form.failSubmit(found)
            return
        }
        form.reset()
        scope.launch {
            val result = controller.signUp(fullName, email, phone, password)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    fun social(provider: AuthProvider) {
        form.reset()
        scope.launch {
            val result = controller.socialSignIn(provider)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    ScreenColumn {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LinkButton("Back to sign in", onClick = { controller.back() })
        }
        Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
            Text(
                "Create your account",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.semantics { heading() },
            )
            Text(
                "We will send a code to your phone to confirm it is yours.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        FormErrorSummary(form)

        Column {
            KlotinTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    form.clear("fullName")
                },
                label = "Full name",
                capitalization = KeyboardCapitalization.Words,
                leadingIcon = Icons.Outlined.Person,
                errorText = form.errors["fullName"],
                focusRequester = form.focus["fullName"],
                onBlur = { if (fullName.isNotBlank()) form.setError("fullName", Validators.validateName(fullName)) },
            )
            KlotinTextField(
                value = email,
                onValueChange = {
                    email = it
                    form.clear("email")
                },
                label = "Email address",
                keyboardType = KeyboardType.Email,
                leadingIcon = Icons.Outlined.Email,
                errorText = form.errors["email"],
                focusRequester = form.focus["email"],
                onBlur = { if (email.isNotBlank()) form.setError("email", Validators.validateEmail(email)) },
            )
            KlotinTextField(
                value = phone,
                onValueChange = {
                    phone = it
                    form.clear("phone")
                },
                label = "Phone number",
                helperText = "Nigerian mobile, like 0803 123 4567",
                keyboardType = KeyboardType.Phone,
                leadingIcon = Icons.Outlined.Phone,
                errorText = form.errors["phone"],
                focusRequester = form.focus["phone"],
                onBlur = { if (phone.isNotBlank()) form.setError("phone", Validators.validatePhone(phone)) },
            )
            PasswordField(
                value = password,
                onValueChange = {
                    password = it
                    form.clear("password")
                },
                label = "Create a password",
                errorText = form.errors["password"],
                focusRequester = form.focus["password"],
                onImeAction = { submit() },
            )
            PasswordRules(password)
        }

        PrimaryButton("Create account", onClick = { submit() }, loading = busy)

        OrDivider()

        SecondaryButton(
            "Sign up with Google",
            onClick = { social(AuthProvider.GOOGLE) },
            enabled = !busy,
            icon = Icons.Outlined.AccountCircle,
        )
        SecondaryButton(
            "Sign up with Facebook",
            onClick = { social(AuthProvider.FACEBOOK) },
            enabled = !busy,
            icon = Icons.Outlined.AccountCircle,
        )
        Spacer(Modifier.height(Space.md))
    }
}

/** Live checklist under the password field. Each rule has an icon and words, not colour alone. */
@Composable
private fun PasswordRules(password: String) {
    val rules = listOf(
        "At least ${Validators.MIN_PASSWORD_LENGTH} characters" to (password.length >= Validators.MIN_PASSWORD_LENGTH),
        "A letter" to password.any { it.isLetter() },
        "A number" to password.any { it.isDigit() },
    )
    Column(
        modifier = Modifier.padding(start = Space.xs, top = Space.xs),
        verticalArrangement = Arrangement.spacedBy(Space.xs),
    ) {
        rules.forEach { (text, met) ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                Icon(
                    imageVector = if (met) Icons.Outlined.Check else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = if (met) "Met" else "Not met",
                    tint = if (met) klotinExtras.success else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(IconSize.sm),
                )
                Text(
                    text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (met) klotinExtras.success else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
