# Klotin release rules. Nothing special is needed yet: the app uses no reflection.
# When you add a networking layer (Retrofit, Ktor, Moshi, ...), add its rules here.
