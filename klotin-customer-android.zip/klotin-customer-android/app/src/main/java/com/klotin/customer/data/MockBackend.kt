package com.klotin.customer.data

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.security.MessageDigest
import kotlin.random.Random

/**
 * A stand-in for the Klotin server. It keeps accounts in a local JSON document so the app
 * works end to end without a network. Every rule a real server must enforce (unique email
 * and phone, OTP expiry and attempt limits, address limits) is already here, so replacing
 * this class with API calls changes the transport, not the app.
 *
 * Demo shortcuts that a real backend must NOT copy:
 *  - OTPs are returned to the app in [OtpTicket.demoCode] instead of sent by SMS or email.
 *  - Social sign-in returns a fixed demo profile instead of verifying a Google or Facebook token.
 *  - Passwords are hashed with a single SHA-256. Use bcrypt or argon2 on a server.
 *  - ID documents are "reviewed" by [demoDecideIdentity], which a real reviewer would do.
 */
class MockBackend(
    private val store: KeyValueStore,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val randomCode: () -> Int = { Random.nextInt(1_000_000) },
) {
    private class OtpState(val code: String, val sentAt: Long, val expiresAt: Long, var attempts: Int)

    private val mutex = Mutex()
    private var db: Db? = null
    private val otps = mutableMapOf<String, OtpState>()

    companion object {
        const val OTP_TTL_MS = 5 * 60 * 1000L
        const val OTP_RESEND_MS = 30 * 1000L
        const val OTP_MAX_ATTEMPTS = 5
    }

    // ---- session -----------------------------------------------------------------------

    suspend fun restore(): User? = mutex.withLock {
        val d = load()
        d.users.firstOrNull { it.user.id == d.sessionUserId }?.user
    }

    suspend fun register(fullName: String, email: String, phone: String, password: String): User =
        mutex.withLock {
            val errors = Validators.validateRegistration(fullName, email, phone, password)
            errors.entries.firstOrNull()?.let { fail(ErrorCode.VALIDATION, it.value, it.key) }

            val normalizedEmail = Validators.normalizeEmail(email)
            val normalizedPhone = Validators.normalizePhone(phone)!!
            val d = load()
            if (d.users.any { it.user.email == normalizedEmail }) {
                fail(ErrorCode.EMAIL_IN_USE, "An account with this email already exists. Sign in instead.", "email")
            }
            if (d.users.any { it.user.phone == normalizedPhone }) {
                fail(ErrorCode.PHONE_IN_USE, "An account with this phone number already exists. Sign in instead.", "phone")
            }

            val id = "usr_${d.seq + 1}"
            val user = User(
                id = id,
                fullName = fullName.trim(),
                email = normalizedEmail,
                phone = normalizedPhone,
                emailVerified = false,
                phoneVerified = false,
                provider = AuthProvider.PASSWORD,
                addresses = emptyList(),
                identity = IdentityVerification(),
                createdAt = clock(),
            )
            commit(d.copy(users = d.users + StoredUser(user, hashPassword(password)), sessionUserId = id, seq = d.seq + 1))
            user
        }

    /** [identifier] is an email address or a Nigerian phone number. */
    suspend fun login(identifier: String, password: String): User = mutex.withLock {
        if (identifier.isBlank()) fail(ErrorCode.VALIDATION, "Enter your email or phone number.", "identifier")
        if (password.isEmpty()) fail(ErrorCode.VALIDATION, "Enter your password.", "password")

        val d = load()
        val match = if ('@' in identifier) {
            val email = Validators.normalizeEmail(identifier)
            d.users.firstOrNull { it.user.email == email }
        } else {
            val phone = Validators.normalizePhone(identifier)
            d.users.firstOrNull { phone != null && it.user.phone == phone }
        }
        // One message for "no such account" and "wrong password" so the form cannot be used to probe for accounts.
        if (match == null || match.passwordHash == null || match.passwordHash != hashPassword(password)) {
            fail(ErrorCode.INVALID_CREDENTIALS, "Email, phone or password is incorrect.")
        }
        commit(d.copy(sessionUserId = match.user.id))
        match.user
    }

    suspend fun socialLogin(provider: AuthProvider): User = mutex.withLock {
        require(provider != AuthProvider.PASSWORD) { "Use login() for password accounts." }
        val d = load()
        val name = if (provider == AuthProvider.GOOGLE) "Demo Google User" else "Demo Facebook User"
        val email = "demo.${provider.name.lowercase()}@klotin.app"

        val existing = d.users.firstOrNull { it.user.email == email }
        if (existing != null) {
            if (existing.user.provider != provider) {
                fail(ErrorCode.EMAIL_IN_USE, "An account with this email already exists. Sign in with your password.")
            }
            commit(d.copy(sessionUserId = existing.user.id))
            return@withLock existing.user
        }

        val id = "usr_${d.seq + 1}"
        val user = User(
            id = id,
            fullName = name,
            email = email,
            phone = null,
            emailVerified = true, // the provider has already verified the email
            phoneVerified = false,
            provider = provider,
            addresses = emptyList(),
            identity = IdentityVerification(),
            createdAt = clock(),
        )
        commit(d.copy(users = d.users + StoredUser(user, null), sessionUserId = id, seq = d.seq + 1))
        user
    }

    suspend fun logout() = mutex.withLock {
        val d = load()
        commit(d.copy(sessionUserId = null))
    }

    // ---- one-time codes ----------------------------------------------------------------

    /** Issues a code. Asking again inside the resend window returns the code already issued. */
    suspend fun sendOtp(channel: Channel): OtpTicket = mutex.withLock {
        val user = requireUser(load())
        val target = when (channel) {
            Channel.EMAIL -> user.email
            Channel.PHONE -> user.phone
        } ?: fail(ErrorCode.NO_TARGET, "Add a ${channel.name.lowercase()} to your profile first.")

        val now = clock()
        val key = otpKey(user.id, channel)
        val existing = otps[key]
        val state = if (existing != null && now < existing.expiresAt && now - existing.sentAt < OTP_RESEND_MS) {
            existing
        } else {
            OtpState(
                code = randomCode().toString().padStart(6, '0'),
                sentAt = now,
                expiresAt = now + OTP_TTL_MS,
                attempts = 0,
            ).also { otps[key] = it }
        }
        OtpTicket(
            channel = channel,
            maskedTarget = if (channel == Channel.EMAIL) Validators.maskEmail(target) else Validators.maskPhone(target),
            expiresAt = state.expiresAt,
            resendAt = state.sentAt + OTP_RESEND_MS,
            demoCode = state.code,
        )
    }

    suspend fun verifyOtp(channel: Channel, code: String): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)
        val key = otpKey(user.id, channel)
        val state = otps[key] ?: fail(ErrorCode.NO_CODE, "Request a new code.", "code")

        if (clock() >= state.expiresAt) {
            otps.remove(key)
            fail(ErrorCode.CODE_EXPIRED, "That code has expired. Request a new one.", "code")
        }
        if (code != state.code) {
            state.attempts += 1
            val left = OTP_MAX_ATTEMPTS - state.attempts
            if (left <= 0) {
                otps.remove(key)
                fail(ErrorCode.TOO_MANY_ATTEMPTS, "Too many wrong codes. Request a new one.", "code")
            }
            fail(ErrorCode.WRONG_CODE, "That code is not right. $left ${if (left == 1) "attempt" else "attempts"} left.", "code")
        }

        otps.remove(key)
        updateUser(d, user.id) {
            when (channel) {
                Channel.EMAIL -> it.copy(emailVerified = true)
                Channel.PHONE -> it.copy(phoneVerified = true)
            }
        }
    }

    // ---- profile -----------------------------------------------------------------------

    /**
     * Changing the email or phone clears that channel's verified flag, because the new
     * value has not been proven yet. Phone may be left empty only on social accounts.
     */
    suspend fun updateProfile(fullName: String, email: String, phone: String): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)

        Validators.validateName(fullName)?.let { fail(ErrorCode.VALIDATION, it, "fullName") }
        Validators.validateEmail(email)?.let { fail(ErrorCode.VALIDATION, it, "email") }
        val newEmail = Validators.normalizeEmail(email)

        val newPhone: String? = if (phone.isBlank() && user.provider != AuthProvider.PASSWORD) {
            null
        } else {
            Validators.validatePhone(phone)?.let { fail(ErrorCode.VALIDATION, it, "phone") }
            Validators.normalizePhone(phone)
        }

        if (d.users.any { it.user.id != user.id && it.user.email == newEmail }) {
            fail(ErrorCode.EMAIL_IN_USE, "Another account already uses this email.", "email")
        }
        if (newPhone != null && d.users.any { it.user.id != user.id && it.user.phone == newPhone }) {
            fail(ErrorCode.PHONE_IN_USE, "Another account already uses this phone number.", "phone")
        }

        updateUser(d, user.id) {
            it.copy(
                fullName = fullName.trim(),
                email = newEmail,
                phone = newPhone,
                emailVerified = it.emailVerified && newEmail == it.email,
                phoneVerified = it.phoneVerified && newPhone == it.phone,
            )
        }
    }

    // ---- addresses ---------------------------------------------------------------------

    suspend fun saveAddress(draft: AddressDraft): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)

        Validators.validateAddress(draft).entries.firstOrNull()?.let { fail(ErrorCode.VALIDATION, it.value, it.key) }

        val contact = draft.contactPhone.takeIf { it.isNotBlank() }?.let { Validators.normalizePhone(it) }

        if (draft.id == null) {
            if (user.addresses.size >= Validators.MAX_ADDRESSES) {
                fail(
                    ErrorCode.ADDRESS_LIMIT,
                    "You can save up to ${Validators.MAX_ADDRESSES} addresses. Delete one to add another.",
                )
            }
            val makeDefault = draft.makeDefault || user.addresses.isEmpty()
            val address = Address(
                id = "adr_${d.seq + 1}",
                label = draft.label,
                customLabel = if (draft.label == AddressLabel.OTHER) draft.customLabel.trim() else "",
                contactPhone = contact,
                street = draft.street.trim(),
                landmark = draft.landmark.trim(),
                city = draft.city.trim(),
                state = draft.state,
                isDefault = makeDefault,
            )
            val others = if (makeDefault) user.addresses.map { it.copy(isDefault = false) } else user.addresses
            commit(d.copy(seq = d.seq + 1))
            updateUser(load(), user.id) { it.copy(addresses = others + address) }
        } else {
            val existing = user.addresses.firstOrNull { it.id == draft.id }
                ?: fail(ErrorCode.NOT_FOUND, "That address no longer exists.")
            // The default can only move by choosing another default, so there is always exactly one.
            val makeDefault = draft.makeDefault || existing.isDefault
            val updated = existing.copy(
                label = draft.label,
                customLabel = if (draft.label == AddressLabel.OTHER) draft.customLabel.trim() else "",
                contactPhone = contact,
                street = draft.street.trim(),
                landmark = draft.landmark.trim(),
                city = draft.city.trim(),
                state = draft.state,
                isDefault = makeDefault,
            )
            updateUser(d, user.id) { u ->
                u.copy(
                    addresses = u.addresses.map {
                        when {
                            it.id == updated.id -> updated
                            makeDefault -> it.copy(isDefault = false)
                            else -> it
                        }
                    },
                )
            }
        }
    }

    suspend fun deleteAddress(addressId: String): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)
        val target = user.addresses.firstOrNull { it.id == addressId }
            ?: fail(ErrorCode.NOT_FOUND, "That address no longer exists.")
        updateUser(d, user.id) { u ->
            val remaining = u.addresses.filter { it.id != addressId }
            val fixed = if (target.isDefault && remaining.isNotEmpty()) {
                remaining.mapIndexed { i, a -> a.copy(isDefault = i == 0) }
            } else {
                remaining
            }
            u.copy(addresses = fixed)
        }
    }

    suspend fun setDefaultAddress(addressId: String): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)
        if (user.addresses.none { it.id == addressId }) fail(ErrorCode.NOT_FOUND, "That address no longer exists.")
        updateUser(d, user.id) { u -> u.copy(addresses = u.addresses.map { it.copy(isDefault = it.id == addressId) }) }
    }

    // ---- identity verification ---------------------------------------------------------

    suspend fun submitIdentity(type: IdType, number: String): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)
        if (user.identity.status == IdStatus.APPROVED) {
            fail(ErrorCode.INVALID_STATE, "Your identity is already verified.")
        }
        if (user.identity.status == IdStatus.PENDING) {
            fail(ErrorCode.INVALID_STATE, "Your document is already under review.")
        }
        Validators.validateIdNumber(type, number)?.let { fail(ErrorCode.VALIDATION, it, "number") }
        val clean = number.trim().replace(" ", "")
        updateUser(d, user.id) {
            it.copy(
                identity = IdentityVerification(
                    status = IdStatus.PENDING,
                    type = type,
                    last4 = clean.takeLast(4),
                    submittedAt = clock(),
                ),
            )
        }
    }

    /** Demo only: plays the part of the reviewer. A real reviewer decision arrives from the server. */
    suspend fun demoDecideIdentity(approve: Boolean): User = mutex.withLock {
        val d = load()
        val user = requireUser(d)
        if (user.identity.status != IdStatus.PENDING) {
            fail(ErrorCode.INVALID_STATE, "There is no document under review.")
        }
        updateUser(d, user.id) {
            it.copy(
                identity = it.identity.copy(
                    status = if (approve) IdStatus.APPROVED else IdStatus.REJECTED,
                    rejectionReason = if (approve) null else "The name on the document did not match your profile.",
                ),
            )
        }
    }

    // ---- internals ---------------------------------------------------------------------

    private suspend fun load(): Db {
        db?.let { return it }
        return decodeDb(store.read()).also { db = it }
    }

    private suspend fun commit(next: Db) {
        db = next
        store.write(next.encode())
    }

    private fun requireUser(d: Db): User =
        d.users.firstOrNull { it.user.id == d.sessionUserId }?.user
            ?: fail(ErrorCode.NOT_SIGNED_IN, "Sign in to continue.")

    private suspend fun updateUser(d: Db, userId: String, change: (User) -> User): User {
        var updated: User? = null
        val users = d.users.map { stored ->
            if (stored.user.id == userId) {
                change(stored.user).also { updated = it }.let { stored.copy(user = it) }
            } else {
                stored
            }
        }
        commit(d.copy(users = users))
        return updated ?: fail(ErrorCode.NOT_FOUND, "Account not found.")
    }

    private fun otpKey(userId: String, channel: Channel) = "$userId:${channel.name}"

    private fun fail(code: ErrorCode, message: String, field: String? = null): Nothing =
        throw ApiException(code, message, field)

    private fun hashPassword(password: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest("klotin:$password".toByteArray())
            .joinToString("") { "%02x".format(it) }
}
