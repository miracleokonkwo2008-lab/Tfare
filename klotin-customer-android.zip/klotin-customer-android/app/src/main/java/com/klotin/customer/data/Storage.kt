package com.klotin.customer.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first

private val Context.klotinDataStore: DataStore<Preferences> by preferencesDataStore(name = "klotin")

/** Persists the demo database on the device with Jetpack DataStore. */
class DataStoreKeyValueStore(context: Context) : KeyValueStore {
    private val store = context.applicationContext.klotinDataStore
    private val key = stringPreferencesKey("demo_db_v1")

    override suspend fun read(): String? = store.data.first()[key]

    override suspend fun write(value: String) {
        store.edit { it[key] = value }
    }
}
