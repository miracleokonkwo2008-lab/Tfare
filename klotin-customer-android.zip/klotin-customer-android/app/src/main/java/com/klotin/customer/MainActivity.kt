package com.klotin.customer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.klotin.customer.ui.KlotinRoot
import com.klotin.customer.ui.theme.KlotinTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KlotinTheme {
                KlotinRoot()
            }
        }
    }
}
