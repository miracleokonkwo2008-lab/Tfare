package com.klotin.customer.ui.components

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.focus.FocusRequester
import com.klotin.customer.app.Outcome

/**
 * Error and focus state for one form. Field errors sit under their field, and after a failed
 * submit the same errors are listed in [FormErrorSummary], which takes focus (UX rules:
 * "Error Placement" and "Focusable Error Summary").
 *
 * [fields] is the order the fields appear on screen, which is also the order of the summary.
 */
@Stable
class FormState(private val fields: List<String>) {
    val errors = mutableStateMapOf<String, String>()
    val focus: Map<String, FocusRequester> = fields.associateWith { FocusRequester() }
    val summaryFocus = FocusRequester()

    /** An error that belongs to no single field, such as "Email or password is incorrect." */
    var formError by mutableStateOf<String?>(null)
        private set

    /** Counts failed submits so the summary can take focus once per failure. */
    var submitAttempts by mutableIntStateOf(0)
        private set

    val summary: List<Pair<String, String>>
        get() = fields.mapNotNull { f -> errors[f]?.let { f to it } }

    /** Set or clear one field's message, for validate-on-blur and clear-on-edit. */
    fun setError(field: String, message: String?) {
        if (message == null) errors.remove(field) else errors[field] = message
    }

    /** Called when the customer edits a field: its old message no longer applies. */
    fun clear(field: String) {
        errors.remove(field)
        formError = null
    }

    /** Client-side validation failed. */
    fun failSubmit(found: Map<String, String>) {
        errors.clear()
        errors.putAll(found)
        formError = null
        submitAttempts++
    }

    /** The server refused. Field errors go under their field, anything else to the summary. */
    fun failSubmit(outcome: Outcome.Failed) {
        errors.clear()
        val field = outcome.field
        if (field != null && field in focus) {
            errors[field] = outcome.message
            formError = null
        } else {
            formError = outcome.message
        }
        submitAttempts++
    }

    fun reset() {
        errors.clear()
        formError = null
    }
}
