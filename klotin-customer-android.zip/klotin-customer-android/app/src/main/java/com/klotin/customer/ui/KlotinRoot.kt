package com.klotin.customer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.klotin.customer.app.AppController
import com.klotin.customer.app.AppState
import com.klotin.customer.app.AppViewModel
import com.klotin.customer.app.Phase
import com.klotin.customer.app.Route
import com.klotin.customer.app.TabRoutes
import com.klotin.customer.app.UiEvent
import com.klotin.customer.data.User
import com.klotin.customer.ui.screens.AccountScreen
import com.klotin.customer.ui.screens.AddressFormScreen
import com.klotin.customer.ui.screens.AddressesScreen
import com.klotin.customer.ui.screens.BrandMark
import com.klotin.customer.ui.screens.EditProfileScreen
import com.klotin.customer.ui.screens.HomeScreen
import com.klotin.customer.ui.screens.IdentityScreen
import com.klotin.customer.ui.screens.OtpScreen
import com.klotin.customer.ui.screens.SignInScreen
import com.klotin.customer.ui.screens.SignUpScreen
import com.klotin.customer.ui.screens.VerificationScreen
import com.klotin.customer.ui.theme.Space

@Composable
fun KlotinRoot(vm: AppViewModel = viewModel()) {
    val controller = vm.controller
    val state by controller.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    // One-off messages ("Address saved.") arrive as events, so they are shown once and not replayed.
    LaunchedEffect(controller) {
        controller.events.collect { event ->
            when (event) {
                is UiEvent.Message -> {
                    snackbar.currentSnackbarData?.dismiss()
                    snackbar.showSnackbar(event.text)
                }
            }
        }
    }

    // Back pops one screen. At a root it is not handled, so the system leaves the app.
    BackHandler(enabled = state.canGoBack) { controller.back() }

    val route = state.current
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (state.phase == Phase.SIGNED_IN && route != null && route in TabRoutes) {
                KlotinNavBar(selected = route, onSelect = controller::selectTab)
            }
        },
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .consumeWindowInsets(inner)
                .imePadding(),
        ) {
            RouteContent(state, controller)
        }
    }
}

@Composable
private fun RouteContent(state: AppState, controller: AppController) {
    val user = state.user
    when (val route = state.current) {
        null -> Splash()
        Route.SignIn -> SignInScreen(controller, state.busy)
        Route.SignUp -> SignUpScreen(controller, state.busy)
        else -> if (user == null) Splash() else SignedInContent(route, user, state, controller)
    }
}

@Composable
private fun SignedInContent(route: Route, user: User, state: AppState, controller: AppController) {
    when (route) {
        Route.Home -> HomeScreen(user, controller)
        Route.Addresses -> AddressesScreen(user, state.busy, controller)
        Route.Account -> AccountScreen(user, state.busy, controller)
        is Route.Otp -> OtpScreen(route.channel, state.otp, state.busy, controller)
        Route.EditProfile -> EditProfileScreen(user, state.busy, controller)
        is Route.AddressForm -> AddressFormScreen(route.addressId, user, state.busy, controller)
        Route.Verification -> VerificationScreen(user, state.busy, controller)
        Route.Identity -> IdentityScreen(user, state.busy, controller)
        // Signed-out routes cannot be on top while signed in; the controller replaces the whole stack on sign-in.
        Route.SignIn, Route.SignUp -> Splash()
    }
}

@Composable
private fun Splash() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Space.lg)) {
            BrandMark()
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
    }
}

private data class Tab(val route: Route, val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab(Route.Home, "Home", Icons.Outlined.Home),
    Tab(Route.Addresses, "Addresses", Icons.Outlined.LocationOn),
    Tab(Route.Account, "Account", Icons.Outlined.Person),
)

@Composable
private fun KlotinNavBar(selected: Route, onSelect: (Route) -> Unit) {
    NavigationBar {
        Tabs.forEach { tab ->
            NavigationBarItem(
                selected = tab.route == selected,
                onClick = { onSelect(tab.route) },
                icon = { Icon(tab.icon, contentDescription = null) },
                label = { Text(tab.label) },
            )
        }
    }
}
