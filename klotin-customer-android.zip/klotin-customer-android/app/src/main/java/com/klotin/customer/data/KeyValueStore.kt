package com.klotin.customer.data

/** Where the demo backend keeps its single JSON document. */
interface KeyValueStore {
    suspend fun read(): String?
    suspend fun write(value: String)
}

class InMemoryStore(private var value: String? = null) : KeyValueStore {
    override suspend fun read(): String? = value
    override suspend fun write(value: String) {
        this.value = value
    }
}
