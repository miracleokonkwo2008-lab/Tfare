package com.klotin.customer.data

/** A stored account: the public [User] plus the password hash that never leaves the backend. */
internal data class StoredUser(val user: User, val passwordHash: String?)

/** The whole demo database, persisted as one JSON document. */
internal data class Db(
    val users: List<StoredUser> = emptyList(),
    val sessionUserId: String? = null,
    val seq: Int = 0,
)
