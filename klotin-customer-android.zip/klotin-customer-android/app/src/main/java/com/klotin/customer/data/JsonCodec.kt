package com.klotin.customer.data

import org.json.JSONArray
import org.json.JSONObject

private fun JSONObject.stringOrNull(name: String): String? =
    if (!has(name) || isNull(name)) null else getString(name)

private fun JSONObject.longOrNull(name: String): Long? =
    if (!has(name) || isNull(name)) null else getLong(name)

private inline fun <reified E : Enum<E>> JSONObject.enumOr(name: String, fallback: E): E {
    val raw = stringOrNull(name) ?: return fallback
    return enumValues<E>().firstOrNull { it.name == raw } ?: fallback
}

private fun Address.toJson() = JSONObject().apply {
    put("id", id)
    put("label", label.name)
    put("customLabel", customLabel)
    put("contactPhone", contactPhone ?: JSONObject.NULL)
    put("street", street)
    put("landmark", landmark)
    put("city", city)
    put("state", state)
    put("isDefault", isDefault)
}

private fun addressFromJson(o: JSONObject) = Address(
    id = o.getString("id"),
    label = o.enumOr("label", AddressLabel.OTHER),
    customLabel = o.optString("customLabel", ""),
    contactPhone = o.stringOrNull("contactPhone"),
    street = o.optString("street", ""),
    landmark = o.optString("landmark", ""),
    city = o.optString("city", ""),
    state = o.optString("state", ""),
    isDefault = o.optBoolean("isDefault", false),
)

private fun IdentityVerification.toJson() = JSONObject().apply {
    put("status", status.name)
    put("type", type?.name ?: JSONObject.NULL)
    put("last4", last4 ?: JSONObject.NULL)
    put("submittedAt", submittedAt ?: JSONObject.NULL)
    put("rejectionReason", rejectionReason ?: JSONObject.NULL)
}

private fun identityFromJson(o: JSONObject?): IdentityVerification {
    if (o == null) return IdentityVerification()
    val rawType = o.stringOrNull("type")
    return IdentityVerification(
        status = o.enumOr("status", IdStatus.NONE),
        type = IdType.entries.firstOrNull { it.name == rawType },
        last4 = o.stringOrNull("last4"),
        submittedAt = o.longOrNull("submittedAt"),
        rejectionReason = o.stringOrNull("rejectionReason"),
    )
}

private fun StoredUser.toJson() = JSONObject().apply {
    put("id", user.id)
    put("fullName", user.fullName)
    put("email", user.email ?: JSONObject.NULL)
    put("phone", user.phone ?: JSONObject.NULL)
    put("emailVerified", user.emailVerified)
    put("phoneVerified", user.phoneVerified)
    put("provider", user.provider.name)
    put("addresses", JSONArray().also { arr -> user.addresses.forEach { arr.put(it.toJson()) } })
    put("identity", user.identity.toJson())
    put("createdAt", user.createdAt)
    put("passwordHash", passwordHash ?: JSONObject.NULL)
}

private fun storedUserFromJson(o: JSONObject): StoredUser {
    val addressesJson = o.optJSONArray("addresses") ?: JSONArray()
    val addresses = (0 until addressesJson.length()).map { addressFromJson(addressesJson.getJSONObject(it)) }
    return StoredUser(
        user = User(
            id = o.getString("id"),
            fullName = o.optString("fullName", ""),
            email = o.stringOrNull("email"),
            phone = o.stringOrNull("phone"),
            emailVerified = o.optBoolean("emailVerified", false),
            phoneVerified = o.optBoolean("phoneVerified", false),
            provider = o.enumOr("provider", AuthProvider.PASSWORD),
            addresses = addresses,
            identity = identityFromJson(o.optJSONObject("identity")),
            createdAt = o.optLong("createdAt", 0L),
        ),
        passwordHash = o.stringOrNull("passwordHash"),
    )
}

internal fun Db.encode(): String = JSONObject().apply {
    put("users", JSONArray().also { arr -> users.forEach { arr.put(it.toJson()) } })
    put("sessionUserId", sessionUserId ?: JSONObject.NULL)
    put("seq", seq)
}.toString()

/** Returns an empty database when the text is missing or damaged, so a bad file never crashes the app. */
internal fun decodeDb(text: String?): Db {
    if (text.isNullOrBlank()) return Db()
    return try {
        val o = JSONObject(text)
        val arr = o.optJSONArray("users") ?: JSONArray()
        Db(
            users = (0 until arr.length()).map { storedUserFromJson(arr.getJSONObject(it)) },
            sessionUserId = o.stringOrNull("sessionUserId"),
            seq = o.optInt("seq", 0),
        )
    } catch (e: org.json.JSONException) {
        Db()
    }
}
