package com.klotin.customer.data

enum class AuthProvider { PASSWORD, GOOGLE, FACEBOOK }

enum class Channel { EMAIL, PHONE }

enum class AddressLabel(val title: String) {
    HOME("Home"),
    WORK("Work"),
    OTHER("Other"),
}

enum class IdType(val title: String, val hint: String) {
    NIN("NIN", "11 digits"),
    DRIVERS_LICENCE("Driver's licence", "9 to 15 letters or digits"),
    VOTERS_CARD("Voter's card", "9 to 19 letters or digits"),
    PASSPORT("International passport", "1 letter followed by 8 digits"),
}

enum class IdStatus { NONE, PENDING, APPROVED, REJECTED }

data class Address(
    val id: String,
    val label: AddressLabel,
    val customLabel: String,
    val contactPhone: String?,
    val street: String,
    val landmark: String,
    val city: String,
    val state: String,
    val isDefault: Boolean,
) {
    /** What the customer sees as the address name: "Home", "Work" or their own text. */
    val displayLabel: String
        get() = if (label == AddressLabel.OTHER && customLabel.isNotBlank()) customLabel else label.title

    val summary: String
        get() = listOf(street, city, state).filter { it.isNotBlank() }.joinToString(", ")
}

data class IdentityVerification(
    val status: IdStatus = IdStatus.NONE,
    val type: IdType? = null,
    val last4: String? = null,
    val submittedAt: Long? = null,
    val rejectionReason: String? = null,
)

data class User(
    val id: String,
    val fullName: String,
    val email: String?,
    val phone: String?,
    val emailVerified: Boolean,
    val phoneVerified: Boolean,
    val provider: AuthProvider,
    val addresses: List<Address>,
    val identity: IdentityVerification,
    val createdAt: Long,
) {
    val firstName: String
        get() = fullName.trim().substringBefore(' ').ifBlank { "there" }

    val initials: String
        get() = fullName.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            .take(2).joinToString("") { it.first().uppercase() }.ifBlank { "K" }

    val defaultAddress: Address?
        get() = addresses.firstOrNull { it.isDefault } ?: addresses.firstOrNull()
}

/** Everything the address form submits. `id == null` means a new address. */
data class AddressDraft(
    val id: String?,
    val label: AddressLabel,
    val customLabel: String,
    val contactPhone: String,
    val street: String,
    val landmark: String,
    val city: String,
    val state: String,
    val makeDefault: Boolean,
)

/** A one-time code that was just issued. `demoCode` exists only because the demo backend sends no SMS or email. */
data class OtpTicket(
    val channel: Channel,
    val maskedTarget: String,
    val expiresAt: Long,
    val resendAt: Long,
    val demoCode: String,
)

enum class ErrorCode {
    VALIDATION,
    INVALID_CREDENTIALS,
    EMAIL_IN_USE,
    PHONE_IN_USE,
    NOT_SIGNED_IN,
    NO_TARGET,
    NO_CODE,
    CODE_EXPIRED,
    WRONG_CODE,
    TOO_MANY_ATTEMPTS,
    ADDRESS_LIMIT,
    NOT_FOUND,
    INVALID_STATE,
}

/** `field` names the form field the message belongs to, when there is one. */
class ApiException(
    val code: ErrorCode,
    message: String,
    val field: String? = null,
) : Exception(message)
