package com.klotin.customer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.HourglassEmpty
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import com.klotin.customer.app.AppController
import com.klotin.customer.app.Outcome
import com.klotin.customer.app.Route
import com.klotin.customer.data.Channel
import com.klotin.customer.data.IdStatus
import com.klotin.customer.data.IdType
import com.klotin.customer.data.User
import com.klotin.customer.data.Validators
import com.klotin.customer.data.verificationProgress
import com.klotin.customer.ui.components.DemoNote
import com.klotin.customer.ui.components.FormErrorSummary
import com.klotin.customer.ui.components.FormState
import com.klotin.customer.ui.components.KlotinCard
import com.klotin.customer.ui.components.KlotinTextField
import com.klotin.customer.ui.components.KlotinTopBar
import com.klotin.customer.ui.components.PrimaryButton
import com.klotin.customer.ui.components.ScreenColumn
import com.klotin.customer.ui.components.SecondaryButton
import com.klotin.customer.ui.components.SectionTitle
import com.klotin.customer.ui.components.StatusPill
import com.klotin.customer.ui.components.Tone
import com.klotin.customer.ui.theme.IconSize
import com.klotin.customer.ui.theme.MinTouchTarget
import com.klotin.customer.ui.theme.Space
import kotlinx.coroutines.launch

@Composable
fun VerificationScreen(user: User, busy: Boolean, controller: AppController) {
    val scope = rememberCoroutineScope()
    val progress = user.verificationProgress()
    val identity = user.identity

    Column {
        KlotinTopBar(title = "Verification", onBack = { controller.back() })
        ScreenColumn {
            KlotinCard {
                Column(Modifier.padding(Space.md), verticalArrangement = Arrangement.spacedBy(Space.sm)) {
                    Text(
                        if (progress.isComplete) "All steps done" else "${progress.completed} of ${progress.total} steps done",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    LinearProgressIndicator(
                        progress = { progress.completed.toFloat() / progress.total },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                    )
                }
            }

            // Email
            StepCard(
                icon = Icons.Outlined.Email,
                title = "Email address",
                detail = user.email ?: "No email on your profile",
                pill = if (user.emailVerified) {
                    { StatusPill("Verified", Tone.GOOD, Icons.Outlined.CheckCircle) }
                } else {
                    { StatusPill("Not verified", Tone.WARN, Icons.Outlined.ErrorOutline) }
                },
            ) {
                if (!user.emailVerified && user.email != null) {
                    SecondaryButton(
                        "Send a code to my email",
                        onClick = { scope.launch { controller.startOtp(Channel.EMAIL) } },
                        enabled = !busy,
                    )
                }
            }

            // Phone
            StepCard(
                icon = Icons.Outlined.Phone,
                title = "Phone number",
                detail = user.phone?.let { Validators.formatPhone(it) } ?: "No phone number yet",
                pill = if (user.phoneVerified) {
                    { StatusPill("Verified", Tone.GOOD, Icons.Outlined.CheckCircle) }
                } else {
                    { StatusPill("Not verified", Tone.WARN, Icons.Outlined.ErrorOutline) }
                },
            ) {
                if (!user.phoneVerified) {
                    if (user.phone == null) {
                        SecondaryButton("Add a phone number", onClick = { controller.navigate(Route.EditProfile) })
                    } else {
                        SecondaryButton(
                            "Send a code to my phone",
                            onClick = { scope.launch { controller.startOtp(Channel.PHONE) } },
                            enabled = !busy,
                        )
                    }
                }
            }

            // Identity document
            StepCard(
                icon = Icons.Outlined.Badge,
                title = "Identity document",
                detail = when {
                    identity.type != null && identity.last4 != null -> "${identity.type.title}, ends in ${identity.last4}"
                    else -> "NIN, driver's licence, voter's card or passport"
                },
                pill = when (identity.status) {
                    IdStatus.NONE -> { { StatusPill("Not started", Tone.NEUTRAL, Icons.Outlined.RadioButtonUnchecked) } }
                    IdStatus.PENDING -> { { StatusPill("Under review", Tone.WARN, Icons.Outlined.HourglassEmpty) } }
                    IdStatus.APPROVED -> { { StatusPill("Verified", Tone.GOOD, Icons.Outlined.Verified) } }
                    IdStatus.REJECTED -> { { StatusPill("Rejected", Tone.BAD, Icons.Outlined.Cancel) } }
                },
            ) {
                if (identity.status == IdStatus.REJECTED && identity.rejectionReason != null) {
                    Text(
                        identity.rejectionReason,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                when (identity.status) {
                    IdStatus.NONE -> PrimaryButton("Add my ID", onClick = { controller.navigate(Route.Identity) })
                    IdStatus.REJECTED -> PrimaryButton("Submit again", onClick = { controller.navigate(Route.Identity) })
                    IdStatus.PENDING -> Text(
                        "We are checking your document. You will see the result here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    IdStatus.APPROVED -> Unit
                }
            }

            if (identity.status == IdStatus.PENDING) {
                DemoNote("A reviewer decides this on the server in a real build. Pick an outcome to see both states.")
                Row(horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                    SecondaryButton(
                        "Approve",
                        onClick = { scope.launch { controller.demoDecideIdentity(approve = true) } },
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                    )
                    SecondaryButton(
                        "Reject",
                        onClick = { scope.launch { controller.demoDecideIdentity(approve = false) } },
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Spacer(Modifier.height(Space.md))
        }
    }
}

@Composable
private fun StepCard(
    icon: ImageVector,
    title: String,
    detail: String,
    pill: @Composable () -> Unit,
    actions: @Composable () -> Unit,
) {
    KlotinCard {
        Column(Modifier.padding(Space.md), verticalArrangement = Arrangement.spacedBy(Space.sm + Space.xs)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.md)) {
                Icon(
                    icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(IconSize.md),
                )
                Column(Modifier.weight(1f)) {
                    SectionTitle(title)
                    Text(detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            pill()
            actions()
        }
    }
}

// ---- Identity form ---------------------------------------------------------------------

@Composable
fun IdentityScreen(user: User, busy: Boolean, controller: AppController) {
    val scope = rememberCoroutineScope()
    var typeName by rememberSaveable { mutableStateOf((user.identity.type ?: IdType.NIN).name) }
    var number by rememberSaveable { mutableStateOf("") }
    val form = remember { FormState(listOf("number")) }
    val type = IdType.valueOf(typeName)

    fun submit() {
        val problem = Validators.validateIdNumber(type, number)
        if (problem != null) {
            form.failSubmit(mapOf("number" to problem))
            return
        }
        form.reset()
        scope.launch {
            val result = controller.submitIdentity(type, number)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    Column {
        KlotinTopBar(title = "Identity document", onBack = { controller.back() })
        ScreenColumn {
            Text(
                "Choose the document you will use, then enter its number.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            FormErrorSummary(form)

            Column(Modifier.selectableGroup()) {
                IdType.entries.forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = MinTouchTarget)
                            .selectable(
                                selected = option == type,
                                role = Role.RadioButton,
                                onClick = {
                                    typeName = option.name
                                    form.reset()
                                },
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(Space.sm),
                    ) {
                        RadioButton(selected = option == type, onClick = null)
                        Column {
                            Text(option.title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                            Text(option.hint, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            KlotinTextField(
                value = number,
                onValueChange = {
                    number = it
                    form.clear("number")
                },
                label = "${type.title} number",
                keyboardType = if (type == IdType.NIN) KeyboardType.Number else KeyboardType.Text,
                capitalization = KeyboardCapitalization.Characters,
                imeAction = ImeAction.Done,
                onImeAction = { submit() },
                errorText = form.errors["number"],
                focusRequester = form.focus["number"],
            )

            Text(
                "Only the last 4 digits are shown in the app once you submit.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            PrimaryButton("Submit for review", onClick = { submit() }, loading = busy)
            Spacer(Modifier.height(Space.md))
        }
    }
}
