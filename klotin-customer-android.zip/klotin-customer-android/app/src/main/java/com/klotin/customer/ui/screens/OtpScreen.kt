package com.klotin.customer.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.klotin.customer.app.AppController
import com.klotin.customer.app.Outcome
import com.klotin.customer.app.Route
import com.klotin.customer.data.Channel
import com.klotin.customer.data.MockBackend
import com.klotin.customer.data.OtpTicket
import com.klotin.customer.ui.components.DemoNote
import com.klotin.customer.ui.components.FormErrorSummary
import com.klotin.customer.ui.components.FormState
import com.klotin.customer.ui.components.KlotinTextField
import com.klotin.customer.ui.components.KlotinTopBar
import com.klotin.customer.ui.components.LinkButton
import com.klotin.customer.ui.components.PrimaryButton
import com.klotin.customer.ui.components.ScreenColumn
import com.klotin.customer.ui.components.SecondaryButton
import com.klotin.customer.ui.theme.Space
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val CODE_LENGTH = 6

@Composable
fun OtpScreen(
    channel: Channel,
    ticket: OtpTicket?,
    busy: Boolean,
    controller: AppController,
) {
    val scope = rememberCoroutineScope()
    var code by rememberSaveable { mutableStateOf("") }
    val form = remember { FormState(listOf("code")) }
    val noun = if (channel == Channel.PHONE) "phone number" else "email address"

    // The screen can be restored without a ticket. Ask for a fresh code instead of showing a dead end.
    LaunchedEffect(ticket == null) {
        if (ticket == null) controller.resendOtp()
    }

    // Seconds until "Resend" unlocks. Ticks once a second, and only while the screen is showing.
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ticket?.resendAt) {
        val resendAt = ticket?.resendAt ?: return@LaunchedEffect
        now = System.currentTimeMillis()
        while (now < resendAt) {
            delay(1_000)
            now = System.currentTimeMillis()
        }
    }
    val secondsLeft = if (ticket == null) 0 else ((ticket.resendAt - now + 999) / 1_000).toInt().coerceAtLeast(0)

    fun submit(value: String) {
        if (value.length < CODE_LENGTH) {
            form.failSubmit(mapOf("code" to "Enter all $CODE_LENGTH digits."))
            return
        }
        form.reset()
        scope.launch {
            val result = controller.submitOtp(value)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    Column {
        KlotinTopBar(
            title = if (channel == Channel.PHONE) "Verify your phone" else "Verify your email",
            onBack = { controller.back() },
        )
        ScreenColumn {
            Column(verticalArrangement = Arrangement.spacedBy(Space.xs)) {
                Text(
                    "Enter the code",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.semantics { heading() },
                )
                Text(
                    if (ticket != null) "We sent a $CODE_LENGTH-digit code to ${ticket.maskedTarget}. It expires in ${MockBackend.OTP_TTL_MS / 60_000} minutes."
                    else "Getting a new code for your $noun.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (ticket != null) {
                DemoNote("No message is sent from this build. Your code is ${ticket.demoCode}.")
            }

            FormErrorSummary(form)

            // One field, not six boxes, so paste, SMS autofill and screen readers all work.
            KlotinTextField(
                value = code,
                onValueChange = { input ->
                    val digits = input.filter { it.isDigit() }.take(CODE_LENGTH)
                    val completed = digits.length == CODE_LENGTH && code.length < CODE_LENGTH
                    code = digits
                    form.clear("code")
                    if (completed) submit(digits)
                },
                label = "$CODE_LENGTH-digit code",
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done,
                onImeAction = { submit(code) },
                errorText = form.errors["code"],
                focusRequester = form.focus["code"],
                textStyle = MaterialTheme.typography.headlineMedium.copy(letterSpacing = 6.sp, textAlign = TextAlign.Center),
            )

            PrimaryButton("Verify", onClick = { submit(code) }, loading = busy)

            if (ticket != null) {
                SecondaryButton(
                    "Fill in the demo code",
                    onClick = {
                        code = ticket.demoCode
                        form.reset()
                    },
                    enabled = !busy,
                )
            }

            LinkButton(
                text = if (secondsLeft > 0) "Resend code in ${secondsLeft}s" else "Resend code",
                enabled = secondsLeft == 0 && !busy && ticket != null,
                onClick = {
                    scope.launch {
                        code = ""
                        form.reset()
                        controller.resendOtp()
                    }
                },
            )
            if (channel == Channel.PHONE) {
                LinkButton("Wrong number? Edit your profile", onClick = {
                    controller.back()
                    controller.navigate(Route.EditProfile)
                })
            }
            LinkButton("Do this later", onClick = { controller.back() })
            Spacer(Modifier.height(Space.md))
        }
    }
}
