package com.klotin.customer.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Place
import androidx.compose.material.icons.outlined.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.klotin.customer.app.AppController
import com.klotin.customer.app.Outcome
import com.klotin.customer.app.Route
import com.klotin.customer.data.Address
import com.klotin.customer.data.AddressDraft
import com.klotin.customer.data.AddressLabel
import com.klotin.customer.data.User
import com.klotin.customer.data.Validators
import com.klotin.customer.ui.components.FormErrorSummary
import com.klotin.customer.ui.components.FormState
import com.klotin.customer.ui.components.KlotinCard
import com.klotin.customer.ui.components.KlotinTextField
import com.klotin.customer.ui.components.KlotinTopBar
import com.klotin.customer.ui.components.LinkButton
import com.klotin.customer.ui.components.PrimaryButton
import com.klotin.customer.ui.components.ScreenColumn
import com.klotin.customer.ui.components.SectionTitle
import com.klotin.customer.ui.components.StatusPill
import com.klotin.customer.ui.components.Tone
import com.klotin.customer.ui.theme.IconSize
import com.klotin.customer.ui.theme.MinTouchTarget
import com.klotin.customer.ui.theme.Space
import kotlinx.coroutines.launch

private fun AddressLabel.icon(): ImageVector = when (this) {
    AddressLabel.HOME -> Icons.Outlined.Home
    AddressLabel.WORK -> Icons.Outlined.Work
    AddressLabel.OTHER -> Icons.Outlined.Place
}

// ---- List ------------------------------------------------------------------------------

@Composable
fun AddressesScreen(user: User, busy: Boolean, controller: AppController) {
    val scope = rememberCoroutineScope()
    var pendingDelete by remember { mutableStateOf<Address?>(null) }
    val atLimit = user.addresses.size >= Validators.MAX_ADDRESSES

    Column(Modifier.fillMaxSize()) {
        KlotinTopBar(title = "Saved addresses", onBack = null)

        if (user.addresses.isEmpty()) {
            EmptyAddresses(onAdd = { controller.navigate(Route.AddressForm(null)) })
        } else {
            Column(
                modifier = Modifier.padding(horizontal = Space.md),
                verticalArrangement = Arrangement.spacedBy(Space.xs),
            ) {
                if (atLimit) {
                    Text(
                        "You have saved ${Validators.MAX_ADDRESSES} addresses. Delete one to add another.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    PrimaryButton(
                        "Add address",
                        onClick = { controller.navigate(Route.AddressForm(null)) },
                        icon = Icons.Outlined.Add,
                    )
                    Text(
                        "${user.addresses.size} of ${Validators.MAX_ADDRESSES} saved",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = Space.md, vertical = Space.md),
                verticalArrangement = Arrangement.spacedBy(Space.md),
            ) {
                items(user.addresses, key = { it.id }) { address ->
                    AddressCard(
                        address = address,
                        busy = busy,
                        onEdit = { controller.navigate(Route.AddressForm(address.id)) },
                        onMakeDefault = { scope.launch { controller.setDefaultAddress(address.id) } },
                        onDelete = { pendingDelete = address },
                    )
                }
            }
        }
    }

    // Deleting cannot be undone, so it asks first.
    pendingDelete?.let { address ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete this address?") },
            text = { Text("${address.displayLabel}, ${address.summary}") },
            confirmButton = {
                TextButton(onClick = {
                    pendingDelete = null
                    scope.launch { controller.deleteAddress(address.id) }
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("Keep it") }
            },
        )
    }
}

@Composable
private fun EmptyAddresses(onAdd: () -> Unit) {
    ScreenColumn {
        Spacer(Modifier.height(Space.xl))
        Icon(
            Icons.Outlined.LocationOn,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .size(48.dp)
                .align(Alignment.CenterHorizontally),
        )
        Text(
            "No saved addresses yet",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        Text(
            "Save the places you send from and to, such as home and work, so you do not retype them.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        PrimaryButton("Add your first address", onClick = onAdd, icon = Icons.Outlined.Add)
    }
}

@Composable
private fun AddressCard(
    address: Address,
    busy: Boolean,
    onEdit: () -> Unit,
    onMakeDefault: () -> Unit,
    onDelete: () -> Unit,
) {
    KlotinCard {
        Column(Modifier.padding(Space.md), verticalArrangement = Arrangement.spacedBy(Space.sm)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                Icon(
                    address.label.icon(),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(IconSize.md),
                )
                Text(
                    address.displayLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                if (address.isDefault) StatusPill("Default", Tone.GOOD, Icons.Outlined.CheckCircle)
            }
            Text(address.summary, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            if (address.landmark.isNotBlank()) {
                Text(
                    "Landmark: ${address.landmark}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            address.contactPhone?.let {
                Text(
                    "Contact: ${Validators.formatPhone(it)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinkButton("Edit", onClick = onEdit)
                if (!address.isDefault) LinkButton("Make default", onClick = onMakeDefault, enabled = !busy)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDelete, enabled = !busy) {
                    Icon(
                        Icons.Outlined.Delete,
                        contentDescription = "Delete ${address.displayLabel} address",
                        tint = MaterialTheme.colorScheme.error,
                    )
                }
            }
        }
    }
}

// ---- Form ------------------------------------------------------------------------------

@Composable
fun AddressFormScreen(addressId: String?, user: User, busy: Boolean, controller: AppController) {
    val existing = remember(addressId, user.addresses) { user.addresses.firstOrNull { it.id == addressId } }

    // The address was deleted while this screen was open. Leave instead of showing an empty form.
    if (addressId != null && existing == null) {
        LaunchedEffect(Unit) { controller.back() }
        return
    }

    val scope = rememberCoroutineScope()
    var labelName by rememberSaveable { mutableStateOf((existing?.label ?: AddressLabel.HOME).name) }
    var customLabel by rememberSaveable { mutableStateOf(existing?.customLabel.orEmpty()) }
    var street by rememberSaveable { mutableStateOf(existing?.street.orEmpty()) }
    var landmark by rememberSaveable { mutableStateOf(existing?.landmark.orEmpty()) }
    var city by rememberSaveable { mutableStateOf(existing?.city.orEmpty()) }
    var state by rememberSaveable { mutableStateOf(existing?.state.orEmpty()) }
    var contactPhone by rememberSaveable { mutableStateOf(existing?.contactPhone?.let { Validators.formatPhone(it) }.orEmpty()) }
    var makeDefault by rememberSaveable { mutableStateOf(false) }
    var showStates by rememberSaveable { mutableStateOf(false) }
    val form = remember { FormState(listOf("customLabel", "street", "city", "state", "contactPhone")) }

    val label = AddressLabel.valueOf(labelName)
    val isFirst = user.addresses.isEmpty()

    fun submit() {
        val draft = AddressDraft(addressId, label, customLabel, contactPhone, street, landmark, city, state, makeDefault)
        val found = Validators.validateAddress(draft)
        if (found.isNotEmpty()) {
            form.failSubmit(found)
            return
        }
        form.reset()
        scope.launch {
            val result = controller.saveAddress(draft)
            if (result is Outcome.Failed) form.failSubmit(result)
        }
    }

    Column {
        KlotinTopBar(title = if (addressId == null) "Add address" else "Edit address", onBack = { controller.back() })
        ScreenColumn {
            FormErrorSummary(form)

            SectionTitle("Address name")
            Row(horizontalArrangement = Arrangement.spacedBy(Space.sm)) {
                AddressLabel.entries.forEach { option ->
                    FilterChip(
                        selected = option == label,
                        onClick = {
                            labelName = option.name
                            form.clear("customLabel")
                        },
                        label = { Text(option.title) },
                        leadingIcon = {
                            Icon(
                                if (option == label) Icons.Outlined.Check else option.icon(),
                                contentDescription = null,
                                modifier = Modifier.size(IconSize.sm),
                            )
                        },
                    )
                }
            }

            Column {
                if (label == AddressLabel.OTHER) {
                    KlotinTextField(
                        value = customLabel,
                        onValueChange = {
                            customLabel = it
                            form.clear("customLabel")
                        },
                        label = "Name this address",
                        helperText = "For example, Mum's place",
                        capitalization = KeyboardCapitalization.Sentences,
                        errorText = form.errors["customLabel"],
                        focusRequester = form.focus["customLabel"],
                    )
                }
                KlotinTextField(
                    value = street,
                    onValueChange = {
                        street = it
                        form.clear("street")
                    },
                    label = "Street address",
                    capitalization = KeyboardCapitalization.Words,
                    errorText = form.errors["street"],
                    focusRequester = form.focus["street"],
                    onBlur = { if (street.isNotBlank()) form.clear("street") },
                )
                KlotinTextField(
                    value = landmark,
                    onValueChange = { landmark = it },
                    label = "Landmark (optional)",
                    helperText = "Helps the rider find you, like \"opposite the bank\"",
                    capitalization = KeyboardCapitalization.Sentences,
                )
                KlotinTextField(
                    value = city,
                    onValueChange = {
                        city = it
                        form.clear("city")
                    },
                    label = "City or area",
                    capitalization = KeyboardCapitalization.Words,
                    errorText = form.errors["city"],
                    focusRequester = form.focus["city"],
                )
                PickerField(
                    label = "State",
                    value = state,
                    placeholder = "Choose a state",
                    errorText = form.errors["state"],
                    focusRequester = form.focus["state"],
                    onClick = { showStates = true },
                )
                KlotinTextField(
                    value = contactPhone,
                    onValueChange = {
                        contactPhone = it
                        form.clear("contactPhone")
                    },
                    label = "Contact number (optional)",
                    helperText = "Who the rider should call at this address",
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done,
                    onImeAction = { submit() },
                    errorText = form.errors["contactPhone"],
                    focusRequester = form.focus["contactPhone"],
                )
            }

            when {
                existing?.isDefault == true -> Text(
                    "This is your default address.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                isFirst -> Text(
                    "Your first address becomes your default.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                else -> Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = MinTouchTarget)
                        .toggleable(value = makeDefault, role = Role.Checkbox, onValueChange = { makeDefault = it }),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(Space.sm),
                ) {
                    Checkbox(checked = makeDefault, onCheckedChange = null)
                    Text("Use as my default address", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
                }
            }

            PrimaryButton("Save address", onClick = { submit() }, loading = busy)
            Spacer(Modifier.height(Space.md))
        }
    }

    if (showStates) {
        AlertDialog(
            onDismissRequest = { showStates = false },
            title = { Text("Choose a state") },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(Validators.NIGERIAN_STATES, key = { it }) { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = MinTouchTarget)
                                .selectable(
                                    selected = option == state,
                                    role = Role.RadioButton,
                                    onClick = {
                                        state = option
                                        form.clear("state")
                                        showStates = false
                                    },
                                ),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(Space.sm),
                        ) {
                            Text(
                                option,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f),
                            )
                            if (option == state) {
                                Icon(Icons.Outlined.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStates = false }) { Text("Cancel") }
            },
        )
    }
}

/** A field that opens a list instead of a keyboard. Looks like the text fields beside it. */
@Composable
private fun PickerField(
    label: String,
    value: String,
    placeholder: String,
    errorText: String?,
    focusRequester: FocusRequester?,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val hasError = errorText != null
    Column(Modifier.fillMaxWidth()) {
        Surface(
            onClick = onClick,
            shape = MaterialTheme.shapes.small,
            color = scheme.surface,
            border = BorderStroke(if (hasError) 2.dp else 1.dp, if (hasError) scheme.error else scheme.outline),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier),
        ) {
            Row(
                modifier = Modifier.padding(horizontal = Space.md, vertical = Space.sm),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.labelMedium, color = if (hasError) scheme.error else scheme.onSurfaceVariant)
                    Text(
                        value.ifBlank { placeholder },
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (value.isBlank()) scheme.onSurfaceVariant else scheme.onSurface,
                    )
                }
                Icon(Icons.Outlined.ArrowDropDown, contentDescription = null, tint = scheme.onSurfaceVariant)
            }
        }
        Text(
            errorText ?: " ",
            style = MaterialTheme.typography.labelMedium,
            color = scheme.error,
            modifier = Modifier.padding(start = Space.md, top = Space.xs, bottom = Space.xs),
        )
    }
}
