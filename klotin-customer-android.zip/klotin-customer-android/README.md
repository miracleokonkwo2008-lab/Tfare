# Klotin: customer app (Android, Kotlin + Jetpack Compose)

First slice of the customer app: **account and profile**.

| Requirement | Where it lives |
|---|---|
| Email and phone registration | `ui/screens/AuthScreens.kt` (`SignUpScreen`), rules in `data/Validators.kt` |
| OTP verification | `ui/screens/OtpScreen.kt`, code rules in `data/MockBackend.kt` |
| Social login | Google and Facebook buttons on sign-in and sign-up (demo profile, see below) |
| Profile management | `EditProfileScreen`, `AccountScreen` |
| Multiple saved addresses | `ui/screens/AddressScreens.kt` (up to 10, one default, confirm before delete) |
| Profile verification | `ui/screens/VerificationScreens.kt` (email, phone, ID document) |

## Run it

1. Open this folder in Android Studio (current stable). Let Gradle sync. If it flags a version in
   `gradle/libs.versions.toml`, accept the suggested upgrade (see "Not verified" below).
2. Run the `app` configuration on an emulator or phone (Android 8.0 / API 26 or newer).
3. Create an account. The OTP screen shows the code on screen because this build sends nothing.

Unit tests: `./gradlew test` (50 tests covering validation, the mock server and navigation).

## How it is built

```
data/      Models, Validators, MockBackend (stand-in server), storage
app/       AppController (navigation + session logic, no Android types), AppViewModel
ui/        KlotinRoot (routing, bottom bar), screens/, components/, theme/
design-system/klotin/   Generated design system and the decisions made against it
tools/contrast_check.py Checks every colour pair in the theme (run it after changing colours)
```

* One `AppController` owns state as an immutable `StateFlow<AppState>`. Screens read it and call
  its functions. One-off messages ("Address saved.") go through a separate event channel.
* Routes are a `sealed interface Route`. The stack lives in `AppState`, so navigation is plain
  Kotlin and is unit tested. Tabs replace the stack; Back pops one screen; at a root Back leaves the app.
* Forms keep errors in a `FormState`: inline message under the field, plus a summary that takes
  focus after a failed submit.

## Demo shortcuts to replace before release

| Demo behaviour | A real build needs |
|---|---|
| OTP code is shown on screen | An SMS and email provider; the server sends the code and never returns it. |
| Google / Facebook buttons sign in a fixed sample profile | Credential Manager (Google) and Facebook Login, with the token verified on your server. Use the official brand buttons and logos. |
| Passwords hashed with one SHA-256 in `MockBackend` | bcrypt or argon2 on the server. The app should never hash or store passwords. |
| ID check is a number only; a "demo reviewer" approves it | Document photo and selfie capture, a KYC provider or manual review, and a server-side decision. |
| Data stored in app DataStore | Your API. Replace `MockBackend` with a class that has the same functions over HTTP, and `AppViewModel` is the only line that changes. |

## Not verified in the environment this was written in

* **No Android build was run.** There was no Android SDK or network access to Google's Maven
  repository. The data layer and `AppController` (the logic) were compiled and tested with a plain
  Kotlin compiler. The Compose screens were written against stable APIs and checked for missing
  imports with a script, but have not been compiled or seen on a device. Expect to fix a few small
  compile errors on first sync.
* **Dependency versions in `gradle/libs.versions.toml` are unchecked pins**, not looked up against the
  repositories. Let Android Studio upgrade them.
* **Icon names** from `material-icons-extended` were written from memory.
* Fonts: Inter is not bundled; the system font is used. Add `inter.ttf` under `res/font` to use it.
* Text is written in code rather than `strings.xml`, so it is not yet translatable.
* Not covered yet: TalkBack testing on a device, large-font and landscape checks, and any screen
  outside account and profile (delivery requests, tracking, payments).
