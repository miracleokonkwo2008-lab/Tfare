package com.klotin.customer.app

import com.klotin.customer.data.AddressDraft
import com.klotin.customer.data.ApiException
import com.klotin.customer.data.AuthProvider
import com.klotin.customer.data.Channel
import com.klotin.customer.data.ErrorCode
import com.klotin.customer.data.IdType
import com.klotin.customer.data.MockBackend
import com.klotin.customer.data.OtpTicket
import com.klotin.customer.data.User
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.channels.Channel as EventChannel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Typed routes. Add a screen here first; the compiler then points at every `when` that needs it. */
sealed interface Route {
    // Signed out
    data object SignIn : Route
    data object SignUp : Route

    // The three tab roots
    data object Home : Route
    data object Addresses : Route
    data object Account : Route

    // Pushed on top of a tab
    data class Otp(val channel: Channel) : Route
    data object EditProfile : Route
    data class AddressForm(val addressId: String?) : Route
    data object Verification : Route
    data object Identity : Route
}

val TabRoutes: List<Route> = listOf(Route.Home, Route.Addresses, Route.Account)

enum class Phase { LOADING, SIGNED_OUT, SIGNED_IN }

data class AppState(
    val phase: Phase = Phase.LOADING,
    val user: User? = null,
    val stack: List<Route> = emptyList(),
    val busy: Boolean = false,
    /** The code that was last issued, for the screen that asks the customer to type it. */
    val otp: OtpTicket? = null,
) {
    val current: Route? get() = stack.lastOrNull()
    val canGoBack: Boolean get() = stack.size > 1
}

sealed interface UiEvent {
    data class Message(val text: String) : UiEvent
}

/** What a screen gets back from an action. `field` names the form field a message belongs to. */
sealed interface Outcome {
    data object Ok : Outcome
    data class Failed(val message: String, val field: String? = null, val code: ErrorCode? = null) : Outcome
}

/**
 * All session and navigation logic, with no Android types, so it runs in plain JVM tests.
 * [AppViewModel] owns one and gives it `viewModelScope`.
 *
 * Every action runs in [scope], not in the caller's, so a request that has started still
 * finishes (and updates state) if the screen that started it leaves the composition.
 */
class AppController(
    private val backend: MockBackend,
    private val scope: CoroutineScope,
) {
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private val _events = EventChannel<UiEvent>(EventChannel.BUFFERED)
    val events: Flow<UiEvent> = _events.receiveAsFlow()

    init {
        scope.launch {
            val user = backend.restore()
            _state.update { if (user == null) signedOut() else signedIn(user) }
        }
    }

    // ---- navigation --------------------------------------------------------------------

    fun navigate(route: Route) = _state.update { it.copy(stack = it.stack + route) }

    /** Pops one screen. Returns false when already at a root, so the caller can leave the app. */
    fun back(): Boolean {
        var popped = false
        _state.update {
            if (it.stack.size > 1) {
                popped = true
                it.copy(stack = it.stack.dropLast(1), otp = if (it.current is Route.Otp) null else it.otp)
            } else {
                popped = false
                it
            }
        }
        return popped
    }

    /** Tabs are roots: switching replaces the stack, so Back from a tab leaves the app. */
    fun selectTab(tab: Route) {
        require(tab in TabRoutes) { "$tab is not a tab" }
        _state.update { if (it.phase == Phase.SIGNED_IN) it.copy(stack = listOf(tab)) else it }
    }

    // ---- account -----------------------------------------------------------------------

    suspend fun signIn(identifier: String, password: String): Outcome = act {
        val user = backend.login(identifier, password)
        _state.update { signedIn(user) }
    }

    /** After sign-up the customer lands on Home with the phone code screen on top; Back skips it. */
    suspend fun signUp(fullName: String, email: String, phone: String, password: String): Outcome = act {
        val user = backend.register(fullName, email, phone, password)
        val ticket = backend.sendOtp(Channel.PHONE)
        _state.update { signedIn(user).copy(stack = listOf(Route.Home, Route.Otp(Channel.PHONE)), otp = ticket) }
    }

    suspend fun socialSignIn(provider: AuthProvider): Outcome = act {
        val user = backend.socialLogin(provider)
        _state.update { signedIn(user) }
    }

    suspend fun signOut(): Outcome = act {
        backend.logout()
        _state.update { signedOut() }
    }

    // ---- one-time codes ----------------------------------------------------------------

    suspend fun startOtp(channel: Channel): Outcome = act {
        val ticket = backend.sendOtp(channel)
        _state.update { it.copy(otp = ticket, stack = it.stack + Route.Otp(channel)) }
    }

    suspend fun resendOtp(): Outcome = act {
        val channel = (_state.value.current as? Route.Otp)?.channel
            ?: throw ApiException(ErrorCode.INVALID_STATE, "There is no code to resend.")
        val ticket = backend.sendOtp(channel)
        _state.update { it.copy(otp = ticket) }
    }

    suspend fun submitOtp(code: String): Outcome = act {
        val channel = (_state.value.current as? Route.Otp)?.channel
            ?: throw ApiException(ErrorCode.INVALID_STATE, "There is no code to check.")
        val user = backend.verifyOtp(channel, code.trim())
        _state.update { it.copy(user = user, otp = null, stack = it.stack.dropLast(1)) }
        say(if (channel == Channel.PHONE) "Phone number verified." else "Email address verified.")
    }

    // ---- profile, addresses, identity --------------------------------------------------

    suspend fun saveProfile(fullName: String, email: String, phone: String): Outcome = act {
        val before = _state.value.user
        val user = backend.updateProfile(fullName, email, phone)
        _state.update { it.copy(user = user, stack = it.stack.dropLast(1)) }
        val changed = before != null && (before.email != user.email || before.phone != user.phone)
        say(if (changed) "Profile saved. Verify your new contact details." else "Profile saved.")
    }

    suspend fun saveAddress(draft: AddressDraft): Outcome = act {
        val user = backend.saveAddress(draft)
        _state.update { it.copy(user = user, stack = it.stack.dropLast(1)) }
        say(if (draft.id == null) "Address saved." else "Address updated.")
    }

    suspend fun deleteAddress(addressId: String): Outcome = act {
        val user = backend.deleteAddress(addressId)
        _state.update { it.copy(user = user) }
        say("Address deleted.")
    }

    suspend fun setDefaultAddress(addressId: String): Outcome = act {
        val user = backend.setDefaultAddress(addressId)
        _state.update { it.copy(user = user) }
        say("Default address changed.")
    }

    suspend fun submitIdentity(type: IdType, number: String): Outcome = act {
        val user = backend.submitIdentity(type, number)
        _state.update { it.copy(user = user, stack = it.stack.dropLast(1)) }
        say("Document sent for review.")
    }

    /** Demo only. Plays the reviewer so the approved and rejected screens can be seen. */
    suspend fun demoDecideIdentity(approve: Boolean): Outcome = act {
        val user = backend.demoDecideIdentity(approve)
        _state.update { it.copy(user = user) }
        say(if (approve) "Identity approved (demo)." else "Identity rejected (demo).")
    }

    // ---- internals ---------------------------------------------------------------------

    private fun signedIn(user: User) =
        AppState(phase = Phase.SIGNED_IN, user = user, stack = listOf(Route.Home))

    private fun signedOut() =
        AppState(phase = Phase.SIGNED_OUT, user = null, stack = listOf(Route.SignIn))

    private fun say(text: String) {
        _events.trySend(UiEvent.Message(text))
    }

    private suspend fun act(block: suspend () -> Unit): Outcome = scope.async {
        _state.update { it.copy(busy = true) }
        try {
            block()
            Outcome.Ok
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            if (e.code == ErrorCode.NOT_SIGNED_IN) _state.update { signedOut() }
            Outcome.Failed(e.message ?: "Something went wrong.", e.field, e.code)
        } finally {
            _state.update { it.copy(busy = false) }
        }
    }.await()
}
