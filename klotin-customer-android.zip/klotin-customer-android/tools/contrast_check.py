#!/usr/bin/env python3
"""Checks every text/control colour pair in Theme.kt against the thresholds in the
UI UX Pro Max pro-rules: 4.5:1 for text, 3:1 for icons and control boundaries.

Reads the colour values straight from Theme.kt, so it cannot drift from the app.
Run:  python3 tools/contrast_check.py
"""
import re
import sys
from pathlib import Path

THEME = Path(__file__).resolve().parent.parent / "app/src/main/java/com/klotin/customer/ui/theme/Theme.kt"
src = THEME.read_text()


def block(name: str) -> dict:
    m = re.search(rf"val {name} = \w+\((.*?)\n\)", src, re.S)
    if not m:
        sys.exit(f"could not find {name} in Theme.kt")
    return {k: v.upper() for k, v in re.findall(r"(\w+) = Color\(0xFF([0-9A-Fa-f]{6})\)", m.group(1))}


def lum(h: str) -> float:
    def ch(i):
        c = int(h[i:i + 2], 16) / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * ch(0) + 0.7152 * ch(2) + 0.0722 * ch(4)


def ratio(a: str, b: str) -> float:
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


TEXT = 4.5
NONTEXT = 3.0

failures = 0
for theme, extras_name in (("LightColors", "LightExtras"), ("DarkColors", "DarkExtras")):
    c = block(theme)
    x = block(extras_name)
    checks = [
        # (foreground, background, minimum, label)
        (c["onBackground"], c["background"], TEXT, "body text on background"),
        (c["onSurface"], c["surface"], TEXT, "body text on card"),
        (c["onSurfaceVariant"], c["background"], TEXT, "secondary text on background"),
        (c["onSurfaceVariant"], c["surface"], TEXT, "secondary text on card"),
        (c["onSurfaceVariant"], c["surfaceVariant"], TEXT, "secondary text on muted"),
        (c["onPrimary"], c["primary"], TEXT, "text on primary button"),
        (c["onTertiary"], c["tertiary"], TEXT, "text on orange CTA"),
        (c["onSecondary"], c["secondary"], TEXT, "text on secondary"),
        (c["onPrimaryContainer"], c["primaryContainer"], TEXT, "text on primary container"),
        (c["onTertiaryContainer"], c["tertiaryContainer"], TEXT, "text on orange container"),
        (c["onError"], c["error"], TEXT, "text on error"),
        (c["onErrorContainer"], c["errorContainer"], TEXT, "text on error container"),
        (c["error"], c["surface"], TEXT, "error text on card"),
        (c["error"], c["background"], TEXT, "error text on background"),
        (c["primary"], c["surface"], TEXT, "link text on card"),
        (c["primary"], c["background"], TEXT, "link text on background"),
        (x["success"], x["successContainer"], TEXT, "success text on its container"),
        (x["warning"], x["warningContainer"], TEXT, "warning text on its container"),
        (x["success"], c["surface"], TEXT, "success text on card"),
        (x["warning"], c["surface"], TEXT, "warning text on card"),
        (c["outline"], c["surface"], NONTEXT, "input border on card"),
        (c["outline"], c["background"], NONTEXT, "input border on background"),
        (c["primary"], c["surface"], NONTEXT, "focus ring / selected icon on card"),
    ]
    print(f"\n== {theme.replace('Colors', '')} theme ==")
    for fg, bg, need, label in checks:
        r = ratio(fg, bg)
        ok = r >= need
        failures += 0 if ok else 1
        print(f"  {'PASS' if ok else 'FAIL'}  {r:5.2f}:1  (needs {need})  {label}  #{fg} on #{bg}")

print(f"\n{failures} failing pair(s)")
sys.exit(1 if failures else 0)
