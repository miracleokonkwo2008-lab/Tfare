package com.klotin.customer.data

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MockBackendTest {

    private var now = 1_000_000L
    private var nextCode = 123456
    private val store = InMemoryStore()

    private fun backend(s: KeyValueStore = store) =
        MockBackend(s, clock = { now }, randomCode = { nextCode })

    private suspend fun MockBackend.registerAda() =
        register("Ada Obi", "ada@example.com", "0803 123 4567", "lagos2026go")

    private fun expectError(code: ErrorCode, field: String? = null, block: suspend () -> Unit) {
        try {
            runBlocking { block() }
            fail("Expected $code but nothing was thrown")
        } catch (e: ApiException) {
            assertEquals(code, e.code)
            if (field != null) assertEquals(field, e.field)
        }
    }

    // ---- registration and sign-in ------------------------------------------------------

    @Test
    fun registerCreatesAnUnverifiedSignedInAccount() = runBlocking {
        val b = backend()
        val user = b.registerAda()
        assertEquals("ada@example.com", user.email)
        assertEquals("+2348031234567", user.phone)
        assertFalse(user.emailVerified)
        assertFalse(user.phoneVerified)
        assertEquals(AuthProvider.PASSWORD, user.provider)
        assertEquals(user, b.restore())
    }

    @Test
    fun registerRejectsInvalidInputAndDuplicates() {
        val b = backend()
        expectError(ErrorCode.VALIDATION, "email") {
            b.register("Ada Obi", "nope", "0803 123 4567", "lagos2026go")
        }
        runBlocking { b.registerAda() }
        expectError(ErrorCode.EMAIL_IN_USE, "email") {
            b.register("Someone", "ADA@example.com", "0902 000 1111", "lagos2026go")
        }
        expectError(ErrorCode.PHONE_IN_USE, "phone") {
            b.register("Someone", "other@example.com", "+234 803 123 4567", "lagos2026go")
        }
    }

    @Test
    fun loginWorksWithEmailOrPhoneAndHidesWhichPartWasWrong() = runBlocking {
        val b = backend()
        b.registerAda()
        b.logout()
        assertNull(b.restore())

        assertEquals("Ada Obi", b.login("ada@example.com", "lagos2026go").fullName)
        b.logout()
        assertEquals("Ada Obi", b.login("08031234567", "lagos2026go").fullName)
        b.logout()

        expectError(ErrorCode.INVALID_CREDENTIALS) { b.login("ada@example.com", "wrong-pass1") }
        expectError(ErrorCode.INVALID_CREDENTIALS) { b.login("nobody@example.com", "lagos2026go") }
        expectError(ErrorCode.INVALID_CREDENTIALS) { b.login("09020001111", "lagos2026go") }
    }

    @Test
    fun socialLoginCreatesAVerifiedEmailAccountWithoutAPhone() = runBlocking {
        val b = backend()
        val user = b.socialLogin(AuthProvider.GOOGLE)
        assertTrue(user.emailVerified)
        assertNull(user.phone)
        assertFalse(user.phoneVerified)
        b.logout()
        assertEquals(user.id, b.socialLogin(AuthProvider.GOOGLE).id)
        assertEquals(1, backendUserCount())
    }

    private suspend fun backendUserCount(): Int {
        // Reload from the stored document to count accounts.
        return decodeDb(store.read()).users.size
    }

    // ---- one-time codes ----------------------------------------------------------------

    @Test
    fun correctCodeVerifiesThePhone() = runBlocking {
        val b = backend()
        b.registerAda()
        val ticket = b.sendOtp(Channel.PHONE)
        assertEquals("123456", ticket.demoCode)
        assertEquals("+234 803 ••• 4567", ticket.maskedTarget)
        val user = b.verifyOtp(Channel.PHONE, "123456")
        assertTrue(user.phoneVerified)
        assertFalse(user.emailVerified)
    }

    @Test
    fun codeForOneChannelDoesNotVerifyTheOther() {
        val b = backend()
        runBlocking {
            b.registerAda()
            b.sendOtp(Channel.PHONE)
        }
        expectError(ErrorCode.NO_CODE) { b.verifyOtp(Channel.EMAIL, "123456") }
    }

    @Test
    fun wrongCodesCountDownThenLockTheCode() {
        val b = backend()
        runBlocking {
            b.registerAda()
            b.sendOtp(Channel.PHONE)
        }
        repeat(4) { i ->
            try {
                runBlocking { b.verifyOtp(Channel.PHONE, "000000") }
                fail("should not verify")
            } catch (e: ApiException) {
                assertEquals(ErrorCode.WRONG_CODE, e.code)
                assertTrue(e.message!!.contains("${4 - i} attempt"))
            }
        }
        expectError(ErrorCode.TOO_MANY_ATTEMPTS) { b.verifyOtp(Channel.PHONE, "000000") }
        // The code is gone, so even the right digits no longer work.
        expectError(ErrorCode.NO_CODE) { b.verifyOtp(Channel.PHONE, "123456") }
    }

    @Test
    fun expiredCodeIsRejected() {
        val b = backend()
        runBlocking {
            b.registerAda()
            b.sendOtp(Channel.PHONE)
        }
        now += MockBackend.OTP_TTL_MS
        expectError(ErrorCode.CODE_EXPIRED) { b.verifyOtp(Channel.PHONE, "123456") }
    }

    @Test
    fun resendInsideTheWindowReusesTheCodeAndAfterItIssuesANewOne() = runBlocking {
        val b = backend()
        b.registerAda()
        val first = b.sendOtp(Channel.PHONE)
        nextCode = 654321
        now += 10_000
        assertEquals(first.demoCode, b.sendOtp(Channel.PHONE).demoCode)
        now += MockBackend.OTP_RESEND_MS
        val second = b.sendOtp(Channel.PHONE)
        assertEquals("654321", second.demoCode)
        assertEquals(now + MockBackend.OTP_RESEND_MS, second.resendAt)
    }

    @Test
    fun codesArePaddedToSixDigits() = runBlocking {
        nextCode = 42
        val b = backend()
        b.registerAda()
        assertEquals("000042", b.sendOtp(Channel.EMAIL).demoCode)
    }

    @Test
    fun socialAccountWithoutPhoneCannotRequestAPhoneCode() {
        val b = backend()
        runBlocking { b.socialLogin(AuthProvider.FACEBOOK) }
        expectError(ErrorCode.NO_TARGET) { b.sendOtp(Channel.PHONE) }
    }

    // ---- profile -----------------------------------------------------------------------

    @Test
    fun changingEmailOrPhoneClearsOnlyThatVerification() = runBlocking {
        val b = backend()
        b.registerAda()
        b.sendOtp(Channel.PHONE); b.verifyOtp(Channel.PHONE, "123456")
        b.sendOtp(Channel.EMAIL); b.verifyOtp(Channel.EMAIL, "123456")

        val sameContacts = b.updateProfile("Ada N. Obi", "ada@example.com", "08031234567")
        assertEquals("Ada N. Obi", sameContacts.fullName)
        assertTrue(sameContacts.emailVerified)
        assertTrue(sameContacts.phoneVerified)

        val newEmail = b.updateProfile("Ada N. Obi", "ada.obi@example.com", "08031234567")
        assertFalse(newEmail.emailVerified)
        assertTrue(newEmail.phoneVerified)

        val newPhone = b.updateProfile("Ada N. Obi", "ada.obi@example.com", "09021112222")
        assertEquals("+2349021112222", newPhone.phone)
        assertFalse(newPhone.phoneVerified)
    }

    @Test
    fun profileUpdateRejectsContactsOwnedByAnotherAccount() {
        val b = backend()
        runBlocking {
            b.register("Bola Ade", "bola@example.com", "0902 000 1111", "lagos2026go")
            b.logout()
            b.registerAda()
        }
        expectError(ErrorCode.EMAIL_IN_USE, "email") { b.updateProfile("Ada Obi", "bola@example.com", "08031234567") }
        expectError(ErrorCode.PHONE_IN_USE, "phone") { b.updateProfile("Ada Obi", "ada@example.com", "09020001111") }
    }

    @Test
    fun passwordAccountMustKeepAPhoneButSocialAccountMayClearIt() {
        val b = backend()
        runBlocking { b.registerAda() }
        expectError(ErrorCode.VALIDATION, "phone") { b.updateProfile("Ada Obi", "ada@example.com", "") }

        val s = backend(InMemoryStore())
        runBlocking {
            s.socialLogin(AuthProvider.GOOGLE)
            val user = s.updateProfile("Demo Google User", "demo.google@klotin.app", "")
            assertNull(user.phone)
        }
    }

    // ---- addresses ---------------------------------------------------------------------

    private fun draft(
        id: String? = null,
        label: AddressLabel = AddressLabel.HOME,
        street: String = "12 Adeola Odeku St",
        makeDefault: Boolean = false,
        custom: String = "",
    ) = AddressDraft(id, label, custom, "", street, "Opposite the bank", "Victoria Island", "Lagos", makeDefault)

    @Test
    fun firstAddressBecomesDefaultAndANewDefaultReplacesIt() = runBlocking {
        val b = backend()
        b.registerAda()
        val one = b.saveAddress(draft())
        assertEquals(1, one.addresses.size)
        assertTrue(one.addresses.single().isDefault)

        val two = b.saveAddress(draft(label = AddressLabel.WORK, street = "5 Marina Rd"))
        assertEquals(2, two.addresses.size)
        assertEquals(listOf(true, false), two.addresses.map { it.isDefault })

        val three = b.saveAddress(draft(label = AddressLabel.OTHER, custom = "Mum's place", street = "9 Allen Ave", makeDefault = true))
        assertEquals(1, three.addresses.count { it.isDefault })
        assertEquals("Mum's place", three.defaultAddress!!.displayLabel)
    }

    @Test
    fun editingKeepsExactlyOneDefault() = runBlocking {
        val b = backend()
        b.registerAda()
        b.saveAddress(draft())
        val withTwo = b.saveAddress(draft(label = AddressLabel.WORK, street = "5 Marina Rd"))
        val workId = withTwo.addresses[1].id
        val homeId = withTwo.addresses[0].id

        // Unticking "default" on the current default does not leave the account without one.
        val stillDefault = b.saveAddress(draft(id = homeId, street = "14 Adeola Odeku St", makeDefault = false))
        assertEquals("14 Adeola Odeku St", stillDefault.addresses.first { it.id == homeId }.street)
        assertTrue(stillDefault.addresses.first { it.id == homeId }.isDefault)

        val moved = b.saveAddress(draft(id = workId, label = AddressLabel.WORK, street = "5 Marina Rd", makeDefault = true))
        assertEquals(listOf(false, true), moved.addresses.map { it.isDefault })
    }

    @Test
    fun deletingTheDefaultPromotesTheNextAddress() = runBlocking {
        val b = backend()
        b.registerAda()
        b.saveAddress(draft())
        val two = b.saveAddress(draft(label = AddressLabel.WORK, street = "5 Marina Rd"))
        val after = b.deleteAddress(two.addresses.first { it.isDefault }.id)
        assertEquals(1, after.addresses.size)
        assertTrue(after.addresses.single().isDefault)
        assertEquals("Work", after.addresses.single().displayLabel)
        assertEquals(0, b.deleteAddress(after.addresses.single().id).addresses.size)
    }

    @Test
    fun setDefaultMovesTheFlag() = runBlocking {
        val b = backend()
        b.registerAda()
        b.saveAddress(draft())
        val two = b.saveAddress(draft(label = AddressLabel.WORK, street = "5 Marina Rd"))
        val moved = b.setDefaultAddress(two.addresses[1].id)
        assertEquals(listOf(false, true), moved.addresses.map { it.isDefault })
    }

    @Test
    fun addressLimitAndUnknownIdsAreEnforced() {
        val b = backend()
        runBlocking {
            b.registerAda()
            repeat(Validators.MAX_ADDRESSES) { b.saveAddress(draft(street = "$it Allen Ave")) }
        }
        expectError(ErrorCode.ADDRESS_LIMIT) { b.saveAddress(draft(street = "One too many")) }
        expectError(ErrorCode.NOT_FOUND) { b.deleteAddress("adr_missing") }
        expectError(ErrorCode.NOT_FOUND) { b.setDefaultAddress("adr_missing") }
        expectError(ErrorCode.NOT_FOUND) { b.saveAddress(draft(id = "adr_missing")) }
    }

    @Test
    fun invalidAddressIsRejected() {
        val b = backend()
        runBlocking { b.registerAda() }
        expectError(ErrorCode.VALIDATION, "street") { b.saveAddress(draft(street = "")) }
    }

    // ---- identity ----------------------------------------------------------------------

    @Test
    fun identityGoesFromPendingToApprovedOrRejected() = runBlocking {
        val b = backend()
        b.registerAda()

        val pending = b.submitIdentity(IdType.NIN, "123 4567 8901")
        assertEquals(IdStatus.PENDING, pending.identity.status)
        assertEquals("8901", pending.identity.last4)
        assertEquals(IdType.NIN, pending.identity.type)

        val rejected = b.demoDecideIdentity(approve = false)
        assertEquals(IdStatus.REJECTED, rejected.identity.status)
        assertNotNull(rejected.identity.rejectionReason)

        b.submitIdentity(IdType.PASSPORT, "A12345678")
        val approved = b.demoDecideIdentity(approve = true)
        assertEquals(IdStatus.APPROVED, approved.identity.status)
        assertNull(approved.identity.rejectionReason)
    }

    @Test
    fun identityRulesAreEnforced() {
        val b = backend()
        runBlocking { b.registerAda() }
        expectError(ErrorCode.VALIDATION, "number") { b.submitIdentity(IdType.NIN, "123") }
        expectError(ErrorCode.INVALID_STATE) { b.demoDecideIdentity(true) }
        runBlocking { b.submitIdentity(IdType.NIN, "12345678901") }
        expectError(ErrorCode.INVALID_STATE) { b.submitIdentity(IdType.NIN, "12345678901") }
        runBlocking { b.demoDecideIdentity(true) }
        expectError(ErrorCode.INVALID_STATE) { b.submitIdentity(IdType.PASSPORT, "A12345678") }
    }

    // ---- persistence and session -------------------------------------------------------

    @Test
    fun everythingSurvivesARestart() = runBlocking {
        val first = backend()
        first.registerAda()
        first.saveAddress(draft(label = AddressLabel.OTHER, custom = "Mum's place"))
        first.sendOtp(Channel.PHONE); first.verifyOtp(Channel.PHONE, "123456")
        first.submitIdentity(IdType.DRIVERS_LICENCE, "ABC123456789")

        val second = backend() // same store, fresh object
        val restored = second.restore()!!
        assertEquals("Ada Obi", restored.fullName)
        assertTrue(restored.phoneVerified)
        assertEquals("Mum's place", restored.addresses.single().displayLabel)
        assertEquals(IdStatus.PENDING, restored.identity.status)
        assertEquals(IdType.DRIVERS_LICENCE, restored.identity.type)

        // The password hash was stored too, so signing in again still works.
        second.logout()
        assertEquals(restored.id, backend().login("ada@example.com", "lagos2026go").id)
    }

    @Test
    fun damagedStorageStartsEmptyInsteadOfCrashing() = runBlocking {
        assertNull(backend(InMemoryStore("{ not json")).restore())
    }

    @Test
    fun signedOutCallsAreRefused() {
        val b = backend()
        expectError(ErrorCode.NOT_SIGNED_IN) { b.sendOtp(Channel.PHONE) }
        expectError(ErrorCode.NOT_SIGNED_IN) { b.saveAddress(draft()) }
        expectError(ErrorCode.NOT_SIGNED_IN) { b.submitIdentity(IdType.NIN, "12345678901") }
    }
}
