package com.klotin.customer.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.klotin.customer.data.DataStoreKeyValueStore
import com.klotin.customer.data.MockBackend

/**
 * Keeps the controller alive across rotation. To connect a real server, replace [MockBackend]
 * with a class that exposes the same functions over HTTP; nothing above this line changes.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {
    val controller = AppController(
        backend = MockBackend(DataStoreKeyValueStore(application)),
        scope = viewModelScope,
    )
}
